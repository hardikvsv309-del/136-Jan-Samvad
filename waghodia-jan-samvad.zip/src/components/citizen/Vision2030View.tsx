import React from 'react';
import { VISION_IMAGE } from '../../data/waghodia.ts';
import { TRANSLATIONS, VISION_PILLARS } from '../../i18n/translations.ts';
import { Language } from '../../types/index.ts';
import { SafeImage } from '../common/SafeImage.tsx';

interface Vision2030ViewProps {
  language: Language;
  onReportClick: () => void;
}

export const Vision2030View: React.FC<Vision2030ViewProps> = ({ language, onReportClick }) => {
  const t = TRANSLATIONS[language];

  return (
    <div className="max-w-[1200px] mx-auto px-4 sm:px-6 py-8 sm:py-10 space-y-12">
      {/* Editorial Intro Split */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch pb-8 border-b border-slate-200">
        <div className="lg:col-span-6 flex flex-col justify-between space-y-5">
          <div className="space-y-3">
            <h1 className="font-display text-3xl sm:text-4xl font-bold text-slate-900 tracking-tight text-balance">
              {t.visionHeading}
            </h1>
            <p className="text-base sm:text-lg font-medium text-amber-700">{t.visionSub}</p>
            <p className="text-sm sm:text-base text-slate-600 leading-relaxed">{t.visionIntro}</p>
          </div>

          <div>
            <button
              type="button"
              onClick={onReportClick}
              className="min-h-[46px] px-6 py-2.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white text-sm font-semibold transition-colors cursor-pointer"
            >
              {t.heroPrimaryCta}
            </button>
          </div>
        </div>

        <div className="lg:col-span-6">
          <div className="h-full min-h-[240px] rounded-2xl overflow-hidden border border-slate-200 bg-slate-100">
            <SafeImage
              src={VISION_IMAGE}
              alt="Waghodia Vision 2030 Modernized Solar School & Village Infrastructure"
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      </div>

      {/* 8 Development Pillars Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {VISION_PILLARS.map((pillar) => (
          <div
            key={pillar.id}
            className="p-6 sm:p-7 rounded-2xl bg-white border border-slate-200 flex flex-col justify-between space-y-4"
          >
            <div className="space-y-2.5">
              <div className="text-xs font-mono-tabular font-semibold text-amber-700">
                {pillar.num}.
              </div>
              <h2 className="font-display text-xl font-bold text-slate-900">
                {pillar.title[language]}
              </h2>
              <p className="text-sm text-slate-600 leading-relaxed">{pillar.summary[language]}</p>
            </div>
            <div className="pt-3 border-t border-slate-100 text-xs font-semibold text-emerald-700">
              {pillar.target[language]}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
