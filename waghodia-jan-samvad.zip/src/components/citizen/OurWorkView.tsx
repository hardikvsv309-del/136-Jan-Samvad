import React, { useState } from 'react';
import { ArrowRight, Calendar, CheckCircle2 } from 'lucide-react';
import { WAGHODIA_VILLAGES } from '../../data/waghodia.ts';
import { CATEGORY_LABELS, TRANSLATIONS } from '../../i18n/translations.ts';
import { Language, ProblemCategory, PublicWorkItem } from '../../types/index.ts';
import { SafeImage } from '../common/SafeImage.tsx';

interface OurWorkViewProps {
  language: Language;
  works: PublicWorkItem[];
  onTrackCode: (code: string) => void;
}

const WorkShowcaseCard: React.FC<{
  item: PublicWorkItem;
  language: Language;
  onTrackCode: (code: string) => void;
}> = ({ item, language, onTrackCode }) => {
  const t = TRANSLATIONS[language];
  const hasBefore = item.beforePhotos && item.beforePhotos.length > 0;
  const hasAfter = item.afterPhotos && item.afterPhotos.length > 0;
  const [photoMode, setPhotoMode] = useState<'after' | 'before'>(hasAfter ? 'after' : 'before');

  const activePhoto =
    photoMode === 'before'
      ? item.beforePhotos?.[0]
      : item.afterPhotos?.[0] || item.beforePhotos?.[0];

  return (
    <article className="rounded-2xl bg-white border border-slate-200 overflow-hidden grid grid-cols-1 lg:grid-cols-12">
      <div className="lg:col-span-5 bg-slate-100 flex flex-col">
        <div className="relative flex-1 min-h-[240px]">
          <SafeImage
            src={activePhoto}
            alt={item.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute bottom-3 left-3 px-2.5 py-1 rounded-md bg-slate-950/80 text-white text-xs font-medium">
            {photoMode === 'before' ? t.workBeforeLabel : t.workAfterLabel}
          </div>
        </div>
        {(hasBefore || hasAfter) && (
          <div className="p-2.5 bg-slate-50 border-t border-slate-200 flex items-center gap-2">
            {hasBefore && (
              <button
                type="button"
                onClick={() => setPhotoMode('before')}
                className={`flex-1 py-2 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                  photoMode === 'before'
                    ? 'bg-slate-900 text-white'
                    : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-100'
                }`}
              >
                {t.workBeforeLabel}
              </button>
            )}
            {hasAfter && (
              <button
                type="button"
                onClick={() => setPhotoMode('after')}
                className={`flex-1 py-2 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                  photoMode === 'after'
                    ? 'bg-emerald-700 text-white'
                    : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-100'
                }`}
              >
                {t.workAfterLabel}
              </button>
            )}
          </div>
        )}
      </div>

      <div className="lg:col-span-7 p-6 sm:p-8 flex flex-col justify-between space-y-5">
        <div className="space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500">
            <div className="flex items-center gap-2">
              <span className="font-mono-tabular font-semibold text-slate-900">
                {item.complaintCode}
              </span>
              <span aria-hidden="true">·</span>
              <span className="font-medium text-amber-700">
                {(() => {
                  const v = WAGHODIA_VILLAGES.find((vill) => vill.id === item.village);
                  return v
                    ? language === 'gu'
                      ? v.nameGu
                      : language === 'hi'
                        ? v.nameHi
                        : v.nameEn
                    : item.village;
                })()}
              </span>
              <span aria-hidden="true">·</span>
              <span>
                {CATEGORY_LABELS[language][item.category as ProblemCategory] || item.category}
              </span>
            </div>
            <div className="inline-flex items-center gap-1.5 font-mono-tabular text-slate-500">
              <Calendar className="w-3.5 h-3.5" />
              <span>
                {new Date(item.resolvedAt || item.createdAt).toLocaleDateString('en-IN', {
                  day: '2-digit',
                  month: 'short',
                  year: 'numeric',
                })}
              </span>
            </div>
          </div>

          <h2 className="font-display text-xl sm:text-2xl font-bold text-slate-900 leading-snug">
            {item.title}
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2 border-t border-slate-100">
            <div>
              <div className="text-xs font-semibold text-slate-500">{t.workProblemLabel}</div>
              <p className="mt-1 text-sm text-slate-700 leading-relaxed">{item.description}</p>
            </div>
            <div>
              <div className="text-xs font-semibold text-amber-700">{t.workActionLabel}</div>
              <p className="mt-1 text-sm text-slate-700 leading-relaxed">
                {item.actionTaken || '—'}
              </p>
            </div>
            <div>
              <div className="text-xs font-semibold text-emerald-700 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>{t.workResultLabel}</span>
              </div>
              <p className="mt-1 text-sm text-slate-800 font-medium leading-relaxed">
                {item.resultSummary || '—'}
              </p>
            </div>
          </div>
        </div>

        <div className="pt-3 border-t border-slate-100 flex justify-end">
          <button
            type="button"
            onClick={() => onTrackCode(item.complaintCode)}
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-800 hover:text-amber-700 cursor-pointer"
          >
            <span>{t.navTrack}</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </article>
  );
};

export const OurWorkView: React.FC<OurWorkViewProps> = ({ language, works, onTrackCode }) => {
  const t = TRANSLATIONS[language];

  return (
    <div className="max-w-[1200px] mx-auto px-4 sm:px-6 py-8 sm:py-10 space-y-8">
      <div className="space-y-2 pb-6 border-b border-slate-200">
        <h1 className="font-display text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
          {t.workHeading}
        </h1>
        <p className="text-sm sm:text-base text-slate-600">{t.workSub}</p>
      </div>

      {works.length === 0 ? (
        <div className="p-8 rounded-2xl bg-white border border-slate-200 text-center text-sm text-slate-500">
          Resolved showcase works will appear here once published from the admin console.
        </div>
      ) : (
        <div className="space-y-6">
          {works.map((item) => (
            <WorkShowcaseCard
              key={item.id}
              item={item}
              language={language}
              onTrackCode={onTrackCode}
            />
          ))}
        </div>
      )}
    </div>
  );
};
