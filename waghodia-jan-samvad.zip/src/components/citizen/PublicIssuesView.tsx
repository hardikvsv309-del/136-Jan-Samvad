import React, { useCallback, useEffect, useState } from 'react';
import { MapPin, Shield } from 'lucide-react';
import { PROBLEM_CATEGORIES } from '../../data/waghodia.ts';
import { CATEGORY_LABELS, STATUS_LABELS, TRANSLATIONS } from '../../i18n/translations.ts';
import {
  ComplaintStatus,
  Language,
  MapIssuePoint,
  ProblemCategory,
  PublicStats,
} from '../../types/index.ts';
import { VillageSelect } from '../common/VillageSelect.tsx';
import { PublicIssuesMap } from '../maps/PublicIssuesMap.tsx';

interface PublicIssuesViewProps {
  language: Language;
  stats: PublicStats | null;
  initialVillage?: string;
  liveEvent: { type: string; payload: Record<string, unknown> } | null;
  onTrackCode: (code: string) => void;
}

export const PublicIssuesView: React.FC<PublicIssuesViewProps> = ({
  language,
  stats,
  initialVillage,
  liveEvent,
  onTrackCode,
}) => {
  const t = TRANSLATIONS[language];
  const [villageFilter, setVillageFilter] = useState(initialVillage || 'all');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [issues, setIssues] = useState<MapIssuePoint[]>([]);
  const [selectedIssueId, setSelectedIssueId] = useState<number | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (initialVillage) {
      setVillageFilter(initialVillage);
    }
  }, [initialVillage]);

  const loadIssues = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (villageFilter !== 'all') params.set('village', villageFilter);
      if (categoryFilter !== 'all') params.set('category', categoryFilter);
      if (statusFilter !== 'all') params.set('status', statusFilter);

      const res = await fetch(`/api/public/map-issues?${params.toString()}`);
      const data = await res.json();
      if (res.ok) {
        setIssues(data.issues || []);
      }
    } catch (error) {
      console.error('Failed to fetch map issues:', error);
    } finally {
      setLoading(false);
    }
  }, [villageFilter, categoryFilter, statusFilter]);

  useEffect(() => {
    loadIssues();
  }, [loadIssues]);

  useEffect(() => {
    if (liveEvent && (liveEvent.type === 'complaint:created' || liveEvent.type === 'complaint:updated')) {
      loadIssues();
    }
  }, [liveEvent, loadIssues]);

  const getStatusTextClass = (status: ComplaintStatus) => {
    if (status === 'resolved') return 'text-emerald-700';
    if (status === 'in_progress') return 'text-amber-700';
    if (status === 'verified') return 'text-blue-700';
    return 'text-red-700';
  };

  return (
    <div className="max-w-[1200px] mx-auto px-4 sm:px-6 py-8 sm:py-10 space-y-8">
      <div className="space-y-2 pb-6 border-b border-slate-200">
        <h1 className="font-display text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
          {t.issuesHeading}
        </h1>
        <p className="text-sm sm:text-base text-slate-600">{t.issuesSub}</p>
      </div>

      {/* Summary KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 border border-slate-200 rounded-2xl bg-white divide-y lg:divide-y-0 divide-x divide-slate-200 overflow-hidden">
        <div className="p-5">
          <div className="text-xs text-slate-500">{t.statTotal}</div>
          <div className="mt-1 text-2xl font-bold text-slate-900 font-mono-tabular">
            {stats?.total ?? '—'}
          </div>
        </div>
        <div className="p-5">
          <div className="text-xs text-emerald-700 font-medium">{t.statResolved}</div>
          <div className="mt-1 text-2xl font-bold text-emerald-700 font-mono-tabular">
            {stats?.resolved ?? '—'}
          </div>
        </div>
        <div className="p-5">
          <div className="text-xs text-amber-700 font-medium">{t.statFollowUp}</div>
          <div className="mt-1 text-2xl font-bold text-amber-700 font-mono-tabular">
            {stats?.underFollowUp ?? '—'}
          </div>
        </div>
        <div className="p-5">
          <div className="text-xs text-slate-600">{t.statPending}</div>
          <div className="mt-1 text-2xl font-bold text-slate-800 font-mono-tabular">
            {stats?.pending ?? '—'}
          </div>
        </div>
      </div>

      {/* Privacy Notice */}
      <div className="p-4 rounded-xl bg-slate-100 border border-slate-200 flex items-start gap-3 text-xs sm:text-sm text-slate-700">
        <Shield className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
        <span>{t.issuesPrivacyNote}</span>
      </div>

      {/* Filters */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <VillageSelect
          value={villageFilter}
          onChange={setVillageFilter}
          language={language}
          includeAllOption
          allLabel={t.filterAllVillages}
        />

        <select
          value={categoryFilter}
          onChange={(e) => setCategoryFilter(e.target.value)}
          className="min-h-[46px] px-3.5 py-2 rounded-xl border border-slate-300 bg-white text-sm text-slate-900"
        >
          <option value="all">{t.filterAllCategories}</option>
          {PROBLEM_CATEGORIES.map((c) => (
            <option key={c} value={c}>
              {CATEGORY_LABELS[language][c]}
            </option>
          ))}
        </select>

        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="min-h-[46px] px-3.5 py-2 rounded-xl border border-slate-300 bg-white text-sm text-slate-900"
        >
          <option value="all">{t.filterAllStatuses}</option>
          {(['submitted', 'verified', 'in_progress', 'resolved'] as ComplaintStatus[]).map((st) => (
            <option key={st} value={st}>
              {STATUS_LABELS[language][st]}
            </option>
          ))}
        </select>
      </div>

      {/* Interactive Map + Sanitized Issue List */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <div className="lg:col-span-7 space-y-3">
          <PublicIssuesMap
            issues={issues}
            language={language}
            selectedIssueId={selectedIssueId}
            onSelectIssue={(issue) => setSelectedIssueId(issue ? issue.id : null)}
            onTrackIssue={onTrackCode}
          />
          <div className="flex flex-wrap items-center gap-4 text-xs text-slate-600 px-1">
            <span>Legend:</span>
            <span className="font-medium text-emerald-700">● {STATUS_LABELS[language].resolved}</span>
            <span className="font-medium text-amber-700">● {STATUS_LABELS[language].in_progress}</span>
            <span className="font-medium text-blue-700">● {STATUS_LABELS[language].verified}</span>
            <span className="font-medium text-red-700">● {STATUS_LABELS[language].submitted}</span>
          </div>
        </div>

        <div className="lg:col-span-5 rounded-2xl bg-white border border-slate-200 overflow-hidden">
          <div className="px-4 py-3 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-700">
              {issues.length} {language === 'en' ? 'Public Issues' : 'જાહેર નોંધ'}
            </span>
            <span className="text-xs text-slate-500">Tap to focus map</span>
          </div>
          <div className="divide-y divide-slate-100 max-h-[390px] overflow-y-auto">
            {loading ? (
              <div className="p-6 text-sm text-slate-500">Loading issues...</div>
            ) : issues.length === 0 ? (
              <div className="p-6 text-sm text-slate-500">No issues match the selected filters.</div>
            ) : (
              issues.map((issue) => (
                <div
                  key={issue.id}
                  onClick={() => setSelectedIssueId(issue.id)}
                  className={`p-4 cursor-pointer transition-colors ${
                    selectedIssueId === issue.id ? 'bg-amber-50/70' : 'hover:bg-slate-50'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2 text-xs">
                    <span className="font-mono-tabular font-medium text-slate-500">
                      {issue.complaintCode} · {issue.village}
                    </span>
                    <span className={`font-semibold ${getStatusTextClass(issue.status)}`}>
                      {STATUS_LABELS[language][issue.status]}
                    </span>
                  </div>
                  <p className="mt-1 text-sm font-semibold text-slate-900 line-clamp-1">
                    {issue.title}
                  </p>
                  <div className="mt-1.5 flex items-center justify-between text-xs text-slate-500">
                    <span>{CATEGORY_LABELS[language][issue.category as ProblemCategory]}</span>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onTrackCode(issue.complaintCode);
                      }}
                      className="inline-flex items-center gap-1 text-amber-700 hover:text-amber-800 font-medium cursor-pointer"
                    >
                      <MapPin className="w-3 h-3" />
                      <span>{t.navTrack}</span>
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
