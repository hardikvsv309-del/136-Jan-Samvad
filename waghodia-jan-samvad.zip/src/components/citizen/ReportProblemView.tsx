import React, { useEffect, useState } from 'react';
import {
  CheckCircle2,
  Copy,
  Crosshair,
  FileVideo,
  Loader2,
  ShieldCheck,
  Trash2,
  Upload,
} from 'lucide-react';
import { PROBLEM_CATEGORIES, WAGHODIA_CENTER, WAGHODIA_VILLAGES } from '../../data/waghodia.ts';
import { CATEGORY_LABELS, TRANSLATIONS } from '../../i18n/translations.ts';
import { Language, MediaAttachment, ProblemCategory } from '../../types/index.ts';
import { VillageSelect } from '../common/VillageSelect.tsx';
import { LocationPickerMap } from '../maps/LocationPickerMap.tsx';

interface ReportProblemViewProps {
  language: Language;
  initialVillage?: string;
  initialCategory?: ProblemCategory;
  onTrackCode: (code: string) => void;
  onSubmitted: () => void;
}

export const ReportProblemView: React.FC<ReportProblemViewProps> = ({
  language,
  initialVillage,
  initialCategory,
  onTrackCode,
  onSubmitted,
}) => {
  const t = TRANSLATIONS[language];

  const [citizenName, setCitizenName] = useState('');
  const [mobileNumber, setMobileNumber] = useState('');
  const [citizenEmail, setCitizenEmail] = useState('');
  const [village, setVillage] = useState(initialVillage || 'Vaghodia');
  const [category, setCategory] = useState<ProblemCategory>(initialCategory || 'roads');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [locationLabel, setLocationLabel] = useState('');
  const [latitude, setLatitude] = useState(WAGHODIA_CENTER.lat);
  const [longitude, setLongitude] = useState(WAGHODIA_CENTER.lng);
  const [mediaUrls, setMediaUrls] = useState<MediaAttachment[]>([]);
  const [consentAccepted, setConsentAccepted] = useState(true);
  const [website, setWebsite] = useState('');

  const [uploading, setUploading] = useState(false);
  const [locating, setLocating] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [createdCode, setCreatedCode] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (initialVillage) {
      setVillage(initialVillage);
      const vInfo = WAGHODIA_VILLAGES.find((v) => v.id === initialVillage);
      if (vInfo) {
        setLatitude(vInfo.lat);
        setLongitude(vInfo.lng);
      }
    }
  }, [initialVillage]);

  useEffect(() => {
    if (initialCategory) {
      setCategory(initialCategory);
    }
  }, [initialCategory]);

  const handleVillageChange = (villageId: string) => {
    setVillage(villageId);
    const vInfo = WAGHODIA_VILLAGES.find((v) => v.id === villageId);
    if (vInfo) {
      setLatitude(vInfo.lat);
      setLongitude(vInfo.lng);
    }
  };

  const handleUseGps = () => {
    if (!navigator.geolocation) {
      setError('Geolocation is not supported on this browser.');
      return;
    }
    setLocating(true);
    setError(null);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setLatitude(Number(pos.coords.latitude.toFixed(6)));
        setLongitude(Number(pos.coords.longitude.toFixed(6)));
        setLocating(false);
      },
      () => {
        setError('Unable to read GPS location. You can tap the map directly to set the pin.');
        setLocating(false);
      },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFiles = e.target.files;
    if (!selectedFiles || selectedFiles.length === 0) return;

    const remainingSlots = 4 - mediaUrls.length;
    if (remainingSlots <= 0) {
      setError('Maximum 4 files allowed per complaint.');
      return;
    }

    setUploading(true);
    setError(null);
    const formData = new FormData();
    Array.from(selectedFiles)
      .slice(0, remainingSlots)
      .forEach((f) => formData.append('files', f));

    try {
      const res = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Upload failed');
      }
      setMediaUrls((prev) => [...prev, ...(data.files || [])]);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'File upload failed.');
    } finally {
      setUploading(false);
      e.target.value = '';
    }
  };

  const removeMedia = (idx: number) => {
    setMediaUrls((prev) => prev.filter((_, i) => i !== idx));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const digitsOnly = mobileNumber.replace(/\D/g, '');
    if (citizenName.trim().length < 2) {
      setError(t.fieldName);
      return;
    }
    if (!/^[6-9]\d{9}$/.test(digitsOnly)) {
      setError('Please enter a valid 10-digit Indian mobile number starting with 6-9.');
      return;
    }
    if (description.trim().length < 10) {
      setError('Please describe the problem in at least 10 characters.');
      return;
    }
    if (!consentAccepted) {
      setError('Please accept the privacy consent to submit.');
      return;
    }

    setSubmitting(true);
    try {
      const res = await fetch('/api/complaints', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          citizenName: citizenName.trim(),
          mobileNumber: digitsOnly,
          citizenEmail: citizenEmail.trim() || undefined,
          village,
          category,
          title: title.trim() || undefined,
          description: description.trim(),
          latitude,
          longitude,
          locationLabel: locationLabel.trim() || village,
          mediaUrls,
          consentAccepted,
          website,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to register complaint');
      }
      setCreatedCode(data.complaintCode);
      onSubmitted();
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Submission failed. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleCopyCode = () => {
    if (!createdCode) return;
    navigator.clipboard?.writeText(createdCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const resetForm = () => {
    setCreatedCode(null);
    setCitizenName('');
    setMobileNumber('');
    setCitizenEmail('');
    setTitle('');
    setDescription('');
    setLocationLabel('');
    setMediaUrls([]);
    setError(null);
  };

  if (createdCode) {
    return (
      <div className="max-w-xl mx-auto px-4 py-12">
        <div className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 text-center space-y-6">
          <div className="w-12 h-12 rounded-full bg-emerald-50 text-emerald-700 flex items-center justify-center mx-auto">
            <CheckCircle2 className="w-7 h-7" />
          </div>
          <div className="space-y-2">
            <h2 className="font-display text-2xl font-bold text-slate-900">
              {t.submittedSuccessTitle}
            </h2>
            <p className="text-sm text-slate-600">{t.submittedSuccessMsg}</p>
          </div>

          <div className="p-5 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
            <div className="text-xs font-medium text-slate-500">{t.yourComplaintId}</div>
            <div className="text-2xl sm:text-3xl font-bold text-slate-900 font-mono-tabular tracking-tight">
              {createdCode}
            </div>
            <button
              type="button"
              onClick={handleCopyCode}
              className="mt-2 inline-flex items-center gap-1.5 text-xs font-semibold text-amber-700 hover:text-amber-800 cursor-pointer"
            >
              <Copy className="w-3.5 h-3.5" />
              <span>{copied ? t.copiedMsg : t.copyIdBtn}</span>
            </button>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 pt-2">
            <button
              type="button"
              onClick={() => onTrackCode(createdCode)}
              className="flex-1 min-h-[46px] px-5 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-sm font-semibold transition-colors cursor-pointer"
            >
              {t.trackNowBtn}
            </button>
            <button
              type="button"
              onClick={resetForm}
              className="flex-1 min-h-[46px] px-5 py-2.5 rounded-xl border border-slate-300 bg-white hover:bg-slate-50 text-slate-800 text-sm font-medium transition-colors cursor-pointer"
            >
              {t.submitAnotherBtn}
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-[960px] mx-auto px-4 sm:px-6 py-8 sm:py-10">
      <div className="space-y-2 pb-6 border-b border-slate-200">
        <h1 className="font-display text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
          {t.reportTitle}
        </h1>
        <p className="text-sm sm:text-base text-slate-600">{t.reportSubtitle}</p>
      </div>

      <form onSubmit={handleSubmit} className="mt-8 space-y-6">
        <div className="hidden" aria-hidden="true">
          <label htmlFor="website-field">Website</label>
          <input
            id="website-field"
            type="text"
            tabIndex={-1}
            autoComplete="off"
            value={website}
            onChange={(e) => setWebsite(e.target.value)}
          />
        </div>

        {error && (
          <div className="p-4 rounded-xl bg-red-50 border border-red-200 text-sm text-red-800">
            {error}
          </div>
        )}

        {/* Section 1: Citizen Contact */}
        <div className="p-5 sm:p-7 rounded-2xl bg-white border border-slate-200 space-y-5">
          <div className="text-xs font-mono-tabular font-semibold text-amber-700">
            01. {language === 'gu' ? 'નાગરિક વિગત (ખાનગી અને સુરક્ષિત)' : language === 'hi' ? 'नागरिक विवरण (निजी व सुरक्षित)' : 'Citizen Details (Private & Protected)'}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div>
              <label className="block text-sm font-medium text-slate-800 mb-1.5">
                {t.fieldName}
              </label>
              <input
                type="text"
                required
                value={citizenName}
                onChange={(e) => setCitizenName(e.target.value)}
                placeholder={t.fieldNamePh}
                className="w-full min-h-[46px] px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-600"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-800 mb-1.5">
                {t.fieldMobile}
              </label>
              <input
                type="tel"
                inputMode="numeric"
                required
                maxLength={10}
                value={mobileNumber}
                onChange={(e) => setMobileNumber(e.target.value.replace(/\D/g, ''))}
                placeholder={t.fieldMobilePh}
                className="w-full min-h-[46px] px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm text-slate-900 font-mono-tabular focus:outline-none focus:ring-2 focus:ring-amber-600"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-800 mb-1.5">
              {t.fieldEmail}
            </label>
            <input
              type="email"
              value={citizenEmail}
              onChange={(e) => setCitizenEmail(e.target.value)}
              placeholder={t.fieldEmailPh}
              className="w-full min-h-[46px] px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-600"
            />
          </div>
        </div>

        {/* Section 2: Village & Problem Details */}
        <div className="p-5 sm:p-7 rounded-2xl bg-white border border-slate-200 space-y-5">
          <div className="text-xs font-mono-tabular font-semibold text-amber-700">
            02. {language === 'gu' ? 'ગામ અને સમસ્યાની વિગત' : language === 'hi' ? 'गांव और समस्या का विवरण' : 'Village & Issue Details'}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div>
              <label className="block text-sm font-medium text-slate-800 mb-1.5">
                {t.fieldVillage}
              </label>
              <VillageSelect
                value={village}
                onChange={handleVillageChange}
                language={language}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-800 mb-1.5">
                {t.fieldCategory}
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as ProblemCategory)}
                className="w-full min-h-[46px] px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-600"
              >
                {PROBLEM_CATEGORIES.map((cat) => (
                  <option key={cat} value={cat}>
                    {CATEGORY_LABELS[language][cat]}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-800 mb-1.5">
              {t.fieldSubject}
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder={t.fieldSubjectPh}
              className="w-full min-h-[46px] px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-600"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-800 mb-1.5">
              {t.fieldDescription}
            </label>
            <textarea
              required
              rows={4}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder={t.fieldDescriptionPh}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-600"
            />
          </div>
        </div>

        {/* Section 3: Media & Location */}
        <div className="p-5 sm:p-7 rounded-2xl bg-white border border-slate-200 space-y-6">
          <div className="text-xs font-mono-tabular font-semibold text-amber-700">
            03. {language === 'gu' ? 'ફોટો / વિડિયો અને નકશા પર સ્થળ' : language === 'hi' ? 'फोटो / वीडियो और मानचित्र स्थान' : 'Media & Pin Location'}
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-800 mb-1">
              {t.fieldMedia}
            </label>
            <p className="text-xs text-slate-500 mb-3">{t.fieldMediaHint}</p>

            <label className="flex flex-col items-center justify-center p-5 border border-dashed border-slate-300 rounded-xl bg-slate-50 hover:bg-slate-100 cursor-pointer transition-colors">
              {uploading ? (
                <Loader2 className="w-6 h-6 text-amber-600 animate-spin" />
              ) : (
                <Upload className="w-6 h-6 text-slate-500" />
              )}
              <span className="mt-2 text-sm font-medium text-slate-700">
                {uploading ? 'Uploading...' : t.fieldMedia}
              </span>
              <input
                type="file"
                multiple
                accept="image/jpeg,image/png,image/webp,video/mp4,video/webm,video/quicktime"
                onChange={handleFileUpload}
                className="hidden"
                disabled={uploading || mediaUrls.length >= 4}
              />
            </label>

            {mediaUrls.length > 0 && (
              <div className="mt-4 grid grid-cols-2 sm:grid-cols-4 gap-3">
                {mediaUrls.map((m, idx) => (
                  <div
                    key={m.url}
                    className="relative rounded-xl overflow-hidden border border-slate-200 bg-slate-100 aspect-[4/3]"
                  >
                    {m.type === 'video' ? (
                      <div className="w-full h-full flex flex-col items-center justify-center p-2 text-slate-700">
                        <FileVideo className="w-6 h-6 mb-1" />
                        <span className="text-[11px] truncate max-w-full">{m.name}</span>
                      </div>
                    ) : (
                      <img src={m.url} alt={m.name} className="w-full h-full object-cover" />
                    )}
                    <button
                      type="button"
                      onClick={() => removeMedia(idx)}
                      className="absolute top-1.5 right-1.5 p-1.5 rounded-md bg-slate-900/75 text-white hover:bg-red-600 cursor-pointer"
                      aria-label="Remove file"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="pt-4 border-t border-slate-100 space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <label className="block text-sm font-medium text-slate-800">{t.fieldLocation}</label>
                <p className="text-xs text-slate-500 mt-0.5">{t.gpsTip}</p>
              </div>
              <button
                type="button"
                onClick={handleUseGps}
                disabled={locating}
                className="inline-flex items-center justify-center gap-2 min-h-[42px] px-4 py-2 rounded-xl border border-slate-300 bg-white hover:bg-slate-50 text-sm font-medium text-slate-800 whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Crosshair className="w-4 h-4 text-amber-600" />
                <span>{locating ? t.gpsLocating : t.useGpsBtn}</span>
              </button>
            </div>

            <LocationPickerMap
              latitude={latitude}
              longitude={longitude}
              onLocationChange={(lat, lng) => {
                setLatitude(lat);
                setLongitude(lng);
              }}
            />

            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs text-slate-500">
              <span className="font-mono-tabular">
                GPS: {latitude.toFixed(5)}, {longitude.toFixed(5)}
              </span>
              <input
                type="text"
                value={locationLabel}
                onChange={(e) => setLocationLabel(e.target.value)}
                placeholder="Landmark (e.g. Near Dairy / School)"
                className="sm:w-72 px-3 py-1.5 rounded-lg border border-slate-200 text-xs text-slate-800"
              />
            </div>
          </div>
        </div>

        {/* Consent & Submit */}
        <div className="p-5 sm:p-6 rounded-2xl bg-slate-50 border border-slate-200 space-y-5">
          <label className="flex items-start gap-3 cursor-pointer">
            <input
              type="checkbox"
              checked={consentAccepted}
              onChange={(e) => setConsentAccepted(e.target.checked)}
              className="mt-1 w-4 h-4 rounded border-slate-300 text-amber-600 focus:ring-amber-600"
            />
            <span className="text-xs sm:text-sm text-slate-700 leading-relaxed flex items-start gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5 hidden sm:block" />
              <span>{t.privacyConsent}</span>
            </span>
          </label>

          <button
            type="submit"
            disabled={submitting || uploading}
            className="w-full sm:w-auto min-h-[48px] px-8 py-3 rounded-xl bg-amber-600 hover:bg-amber-700 disabled:opacity-60 text-white font-semibold text-base transition-colors cursor-pointer"
          >
            {submitting ? t.submittingBtn : t.submitComplaintBtn}
          </button>
        </div>
      </form>
    </div>
  );
};
