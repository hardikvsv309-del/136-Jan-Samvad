import React, { useCallback, useEffect, useState } from 'react';
import { CheckCircle2, Clock, FileCheck2, Search, Wrench } from 'lucide-react';
import { WAGHODIA_VILLAGES } from '../../data/waghodia.ts';
import { CATEGORY_LABELS, STATUS_LABELS, TRANSLATIONS } from '../../i18n/translations.ts';
import {
  ComplaintStatus,
  Language,
  PublicComplaintTrack,
  TimelineEntry,
} from '../../types/index.ts';
import { SafeImage } from '../common/SafeImage.tsx';

interface TrackComplaintViewProps {
  language: Language;
  initialCode?: string;
  liveEvent: { type: string; payload: Record<string, unknown> } | null;
}

const STEPS: ComplaintStatus[] = ['submitted', 'verified', 'in_progress', 'resolved'];

export const TrackComplaintView: React.FC<TrackComplaintViewProps> = ({
  language,
  initialCode,
  liveEvent,
}) => {
  const t = TRANSLATIONS[language];
  const [queryCode, setQueryCode] = useState(initialCode || 'WJS-2026-0101');
  const [complaint, setComplaint] = useState<PublicComplaintTrack | null>(null);
  const [timeline, setTimeline] = useState<TimelineEntry[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchComplaint = useCallback(
    async (codeToFetch: string) => {
      const clean = codeToFetch.trim().toUpperCase();
      if (!clean) return;
      setLoading(true);
      setError(null);
      try {
        const res = await fetch(`/api/complaints/track/${encodeURIComponent(clean)}`);
        const data = await res.json();
        if (!res.ok) {
          setComplaint(null);
          setTimeline([]);
          setError(t.trackNotFound);
          return;
        }
        setComplaint(data.complaint);
        setTimeline(data.timeline || []);
      } catch {
        setError('Network error while checking complaint status.');
      } finally {
        setLoading(false);
      }
    },
    [t.trackNotFound]
  );

  useEffect(() => {
    if (initialCode) {
      setQueryCode(initialCode);
      fetchComplaint(initialCode);
    } else {
      fetchComplaint('WJS-2026-0101');
    }
  }, [initialCode, fetchComplaint]);

  // Real-time WebSocket update listener for the currently tracked Complaint ID
  useEffect(() => {
    if (!liveEvent || !complaint) return;
    if (
      liveEvent.type === 'complaint:updated' &&
      liveEvent.payload.complaintCode === complaint.complaintCode
    ) {
      setComplaint((prev) =>
        prev
          ? {
              ...prev,
              status: (liveEvent.payload.status as ComplaintStatus) || prev.status,
              actionTaken:
                typeof liveEvent.payload.actionTaken === 'string'
                  ? liveEvent.payload.actionTaken
                  : prev.actionTaken,
              resultSummary:
                typeof liveEvent.payload.resultSummary === 'string'
                  ? liveEvent.payload.resultSummary
                  : prev.resultSummary,
              updatedAt:
                typeof liveEvent.payload.updatedAt === 'string'
                  ? liveEvent.payload.updatedAt
                  : prev.updatedAt,
              resolvedAt:
                typeof liveEvent.payload.resolvedAt === 'string'
                  ? liveEvent.payload.resolvedAt
                  : prev.resolvedAt,
            }
          : prev
      );
      if (Array.isArray(liveEvent.payload.timeline)) {
        setTimeline(liveEvent.payload.timeline as TimelineEntry[]);
      }
    }
  }, [liveEvent, complaint]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    fetchComplaint(queryCode);
  };

  const activeStepIdx = complaint ? STEPS.indexOf(complaint.status) : -1;

  const getStepIcon = (step: ComplaintStatus) => {
    switch (step) {
      case 'submitted':
        return <Clock className="w-4 h-4" />;
      case 'verified':
        return <FileCheck2 className="w-4 h-4" />;
      case 'in_progress':
        return <Wrench className="w-4 h-4" />;
      case 'resolved':
        return <CheckCircle2 className="w-4 h-4" />;
    }
  };

  return (
    <div className="max-w-[980px] mx-auto px-4 sm:px-6 py-8 sm:py-10 space-y-8">
      <div className="space-y-2 pb-6 border-b border-slate-200">
        <h1 className="font-display text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
          {t.trackHeading}
        </h1>
        <p className="text-sm sm:text-base text-slate-600">{t.trackSub}</p>
      </div>

      {/* Search Bar */}
      <div className="space-y-3">
        <form
          onSubmit={handleSubmit}
          className="flex flex-col sm:flex-row gap-3 p-2 bg-white border border-slate-200 rounded-xl"
        >
          <div className="flex-1 flex items-center gap-2.5 px-3">
            <Search className="w-4 h-4 text-slate-400 shrink-0" />
            <input
              type="text"
              value={queryCode}
              onChange={(e) => setQueryCode(e.target.value)}
              placeholder={t.quickTrackPlaceholder}
              className="w-full py-2.5 text-sm sm:text-base text-slate-900 font-mono-tabular bg-transparent focus:outline-none"
            />
          </div>
          <button
            type="submit"
            disabled={loading}
            className="min-h-[44px] px-6 py-2.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white text-sm font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            {loading ? '...' : t.trackSearchBtn}
          </button>
        </form>

        <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
          <span>{t.trackSampleLabel}</span>
          {['WJS-2026-0101', 'WJS-2026-0104', 'WJS-2026-0105', 'WJS-2026-0106'].map((sample) => (
            <button
              key={sample}
              type="button"
              onClick={() => {
                setQueryCode(sample);
                fetchComplaint(sample);
              }}
              className={`px-2.5 py-1 rounded-md font-mono-tabular border transition-colors cursor-pointer ${
                complaint?.complaintCode === sample
                  ? 'bg-slate-900 text-white border-slate-900'
                  : 'bg-white text-slate-700 border-slate-200 hover:border-slate-300'
              }`}
            >
              {sample}
            </button>
          ))}
        </div>
      </div>

      {error && (
        <div className="p-5 rounded-xl bg-red-50 border border-red-200 text-sm text-red-800">
          {error}
        </div>
      )}

      {complaint && (
        <div className="space-y-6">
          {/* Status Card */}
          <div className="p-6 sm:p-8 rounded-2xl bg-white border border-slate-200 space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 pb-5 border-b border-slate-100">
              <div className="space-y-1.5">
                <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
                  <span className="font-mono-tabular font-semibold text-slate-900">
                    {complaint.complaintCode}
                  </span>
                  <span aria-hidden="true">·</span>
                  <span>
                    {(() => {
                      const v = WAGHODIA_VILLAGES.find((item) => item.id === complaint.village);
                      return v
                        ? language === 'gu'
                          ? v.nameGu
                          : language === 'hi'
                            ? v.nameHi
                            : v.nameEn
                        : complaint.village;
                    })()}
                  </span>
                  <span aria-hidden="true">·</span>
                  <span>{CATEGORY_LABELS[language][complaint.category] || complaint.category}</span>
                </div>
                <h2 className="font-display text-xl sm:text-2xl font-bold text-slate-900">
                  {complaint.title}
                </h2>
                <p className="text-sm text-slate-600 leading-relaxed">{complaint.description}</p>
              </div>
              <div className="shrink-0 text-left sm:text-right">
                <div className="text-xs text-slate-500">{t.trackLiveLabel}</div>
                <div
                  className={`mt-1 text-sm font-semibold ${
                    complaint.status === 'resolved'
                      ? 'text-emerald-700'
                      : complaint.status === 'in_progress'
                        ? 'text-amber-700'
                        : 'text-slate-800'
                  }`}
                >
                  {STATUS_LABELS[language][complaint.status]}
                </div>
              </div>
            </div>

            {/* 4-Stage Stepper */}
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
              {STEPS.map((step, idx) => {
                const done = idx <= activeStepIdx;
                const isCurrent = idx === activeStepIdx;
                return (
                  <div
                    key={step}
                    className={`p-3.5 rounded-xl border transition-colors ${
                      isCurrent
                        ? 'border-amber-600 bg-amber-50/60'
                        : done
                          ? 'border-emerald-200 bg-emerald-50/40'
                          : 'border-slate-200 bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span
                        className={`${
                          isCurrent
                            ? 'text-amber-700'
                            : done
                              ? 'text-emerald-700'
                              : 'text-slate-400'
                        }`}
                      >
                        {getStepIcon(step)}
                      </span>
                      <span
                        className={`text-xs font-semibold ${
                          done ? 'text-slate-900' : 'text-slate-500'
                        }`}
                      >
                        {STATUS_LABELS[language][step]}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Action Taken & Result */}
            {(complaint.actionTaken || complaint.resultSummary) && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                {complaint.actionTaken && (
                  <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
                    <div className="text-xs font-semibold text-slate-500">
                      {t.trackActionLabel}
                    </div>
                    <p className="mt-1 text-sm text-slate-800 leading-relaxed">
                      {complaint.actionTaken}
                    </p>
                  </div>
                )}
                {complaint.resultSummary && (
                  <div className="p-4 rounded-xl bg-emerald-50/50 border border-emerald-200">
                    <div className="text-xs font-semibold text-emerald-800">
                      {t.trackResultLabel}
                    </div>
                    <p className="mt-1 text-sm text-slate-800 leading-relaxed">
                      {complaint.resultSummary}
                    </p>
                  </div>
                )}
              </div>
            )}

            {/* Before / After Photos if available */}
            {(complaint.beforePhotos?.length > 0 || complaint.afterPhotos?.length > 0) && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                {complaint.beforePhotos?.[0] && (
                  <div className="space-y-1.5">
                    <div className="text-xs font-medium text-slate-500">{t.workBeforeLabel}</div>
                    <SafeImage
                      src={complaint.beforePhotos[0]}
                      alt="Before resolution"
                      className="w-full aspect-[4/3] object-cover rounded-xl border border-slate-200"
                    />
                  </div>
                )}
                {complaint.afterPhotos?.[0] && (
                  <div className="space-y-1.5">
                    <div className="text-xs font-medium text-emerald-700">{t.workAfterLabel}</div>
                    <SafeImage
                      src={complaint.afterPhotos[0]}
                      alt="After resolution"
                      className="w-full aspect-[4/3] object-cover rounded-xl border border-slate-200"
                    />
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Chronological Public Timeline */}
          <div className="p-6 sm:p-8 rounded-2xl bg-white border border-slate-200 space-y-4">
            <h3 className="font-display text-lg font-bold text-slate-900">
              {t.trackTimelineTitle}
            </h3>
            <div className="divide-y divide-slate-100">
              {timeline.map((entry) => (
                <div key={entry.id} className="py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="space-y-0.5">
                    <div className="text-xs font-semibold text-amber-700">
                      {STATUS_LABELS[language][entry.status] || entry.status}
                    </div>
                    <p className="text-sm text-slate-800">{entry.publicNote}</p>
                    <div className="text-xs text-slate-500">{entry.actorName}</div>
                  </div>
                  <div className="text-xs text-slate-500 font-mono-tabular shrink-0">
                    {new Date(entry.createdAt).toLocaleString('en-IN', {
                      day: '2-digit',
                      month: 'short',
                      year: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
