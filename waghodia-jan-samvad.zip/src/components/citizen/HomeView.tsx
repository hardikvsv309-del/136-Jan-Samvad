import React, { useMemo, useState } from 'react';
import {
  ArrowRight,
  Building2,
  Bus,
  CheckCircle2,
  Clock,
  Droplets,
  GraduationCap,
  HeartPulse,
  Mail,
  MapPin,
  Phone,
  Route,
  Search,
  ShieldCheck,
  Sprout,
  Users,
  Waves,
  Zap,
} from 'lucide-react';
import { motion } from 'motion/react';
import { HERO_IMAGE, WAGHODIA_VILLAGES } from '../../data/waghodia.ts';
import { CATEGORY_LABELS, TRANSLATIONS } from '../../i18n/translations.ts';
import { Language, ProblemCategory, PublicStats, PublicUpdateItem } from '../../types/index.ts';
import { SafeImage } from '../common/SafeImage.tsx';

interface HomeViewProps {
  language: Language;
  stats: PublicStats | null;
  updates: PublicUpdateItem[];
  onNavigate: (tab: 'report' | 'track' | 'issues' | 'work' | 'vision') => void;
  onReportWithPreset: (opts: { village?: string; category?: ProblemCategory }) => void;
  onViewVillageIssues: (villageId: string) => void;
  onTrackCode: (code: string) => void;
}

const FEATURED_CATEGORIES: Array<{
  id: ProblemCategory;
  icon: React.FC<{ className?: string }>;
}> = [
  { id: 'roads', icon: Route },
  { id: 'drinking_water', icon: Droplets },
  { id: 'drainage', icon: Waves },
  { id: 'electricity', icon: Zap },
  { id: 'education', icon: GraduationCap },
  { id: 'healthcare', icon: HeartPulse },
  { id: 'agriculture', icon: Sprout },
  { id: 'transport', icon: Bus },
];

export const HomeView: React.FC<HomeViewProps> = ({
  language,
  stats,
  updates,
  onNavigate,
  onReportWithPreset,
  onViewVillageIssues,
  onTrackCode,
}) => {
  const t = TRANSLATIONS[language];
  const [trackInput, setTrackInput] = useState('');
  const [villageQuery, setVillageQuery] = useState('');
  const [showAllVillages, setShowAllVillages] = useState(false);

  const handleQuickTrack = (e: React.FormEvent) => {
    e.preventDefault();
    if (trackInput.trim()) {
      onTrackCode(trackInput.trim().toUpperCase());
    }
  };

  const getLocalizedVillage = (villageId: string) => {
    const found = WAGHODIA_VILLAGES.find((v) => v.id === villageId);
    if (!found) return villageId;
    return language === 'gu' ? found.nameGu : language === 'hi' ? found.nameHi : found.nameEn;
  };

  const filteredVillages = useMemo(() => {
    const q = villageQuery.trim().toLowerCase();
    const list = q
      ? WAGHODIA_VILLAGES.filter(
          (v) =>
            v.nameEn.toLowerCase().includes(q) ||
            v.nameGu.includes(q) ||
            v.nameHi.includes(q)
        )
      : WAGHODIA_VILLAGES;
    return q || showAllVillages ? list : list.slice(0, 18);
  }, [villageQuery, showAllVillages]);

  return (
    <div className="space-y-16 pb-16">
      {/* Architectural Hero Band */}
      <section className="bg-slate-900 text-white border-b border-slate-800">
        <div className="max-w-[1200px] mx-auto px-4 sm:px-6 py-10 md:py-14">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-stretch">
            <motion.div
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.25 }}
              className="lg:col-span-7 flex flex-col justify-between space-y-6 py-1"
            >
              <div className="space-y-4">
                <p className="text-xs sm:text-sm font-medium text-amber-400 tracking-wide">
                  {t.heroEyebrow}
                </p>
                <h1
                  className="font-display font-bold text-white tracking-tight text-balance leading-[1.14]"
                  style={{ fontSize: 'clamp(1.95rem, 3.6vw, 3.15rem)' }}
                >
                  {t.heroTitle}
                </h1>
                <p className="text-base sm:text-lg text-slate-300 leading-relaxed max-w-2xl">
                  {t.heroSubtitle}
                </p>
              </div>

              <div className="space-y-5">
                <div className="flex flex-wrap items-center gap-3">
                  <button
                    type="button"
                    onClick={() => onNavigate('report')}
                    className="inline-flex items-center justify-center gap-2 min-h-[48px] px-6 py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-sm sm:text-base transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    <span>{t.heroPrimaryCta}</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => onNavigate('work')}
                    className="inline-flex items-center justify-center gap-2 min-h-[48px] px-5 py-3 rounded-xl border border-slate-700 bg-slate-800/70 hover:bg-slate-800 text-white font-medium text-sm sm:text-base transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    <span>{t.heroSecondaryCta}</span>
                  </button>
                </div>

                {/* Quick Complaint Tracking Bar */}
                <form
                  onSubmit={handleQuickTrack}
                  className="flex flex-col sm:flex-row gap-2 p-2 bg-slate-800/90 border border-slate-700 rounded-xl max-w-xl"
                >
                  <div className="flex-1 flex items-center gap-2.5 px-3">
                    <Search className="w-4 h-4 text-slate-400 shrink-0" />
                    <input
                      type="text"
                      value={trackInput}
                      onChange={(e) => setTrackInput(e.target.value)}
                      placeholder={t.quickTrackPlaceholder}
                      className="w-full py-2 text-sm text-white placeholder:text-slate-400 bg-transparent focus:outline-none font-mono-tabular"
                    />
                  </div>
                  <button
                    type="submit"
                    className="min-h-[42px] px-5 py-2 rounded-lg bg-white hover:bg-slate-100 text-slate-900 text-sm font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    {t.quickTrackBtn}
                  </button>
                </form>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.05 }}
              className="lg:col-span-5"
            >
              <div className="h-full min-h-[260px] lg:min-h-[390px] rounded-2xl overflow-hidden border border-slate-700 bg-slate-800 relative">
                <SafeImage
                  src={HERO_IMAGE}
                  alt="Waghodia Constituency Civic Center & Roads"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-slate-950/90 via-slate-950/45 to-transparent p-5 text-white">
                  <div className="text-xs text-amber-300 font-medium font-mono-tabular">
                    {language === 'gu'
                      ? 'વાઘોડિયા તાલુકા · ૯૬ ગામોનું ડિજિટલ નેટવર્ક'
                      : language === 'hi'
                        ? 'वाघोडिया तालुका · 96 गांवों का डिजिटल नेटवर्क'
                        : 'Waghodia Taluka · 96 Villages Connected'}
                  </div>
                  <div className="text-sm font-medium text-white/95 mt-0.5">
                    {language === 'gu'
                      ? 'સીધો નાગરિક સંવાદ અને પારદર્શક વિકાસ'
                      : language === 'hi'
                        ? 'सीधा नागरिक संवाद और पारदर्शी विकास'
                        : 'Direct Citizen Redressal & Transparent Delivery'}
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* 4-Column Public Statistics Strip overlapping gracefully */}
      <section className="max-w-[1200px] mx-auto px-4 sm:px-6 -mt-10">
        <div className="grid grid-cols-2 lg:grid-cols-4 border border-slate-200 rounded-2xl bg-white shadow-sm divide-y lg:divide-y-0 divide-x divide-slate-200 overflow-hidden">
          <div className="p-5 sm:p-6">
            <div className="text-xs sm:text-sm text-slate-500">{t.statTotal}</div>
            <div className="mt-1.5 text-2xl sm:text-3xl font-bold text-slate-900 font-mono-tabular">
              {stats ? stats.total : '—'}
            </div>
          </div>
          <div className="p-5 sm:p-6">
            <div className="text-xs sm:text-sm text-emerald-700 font-medium">{t.statResolved}</div>
            <div className="mt-1.5 text-2xl sm:text-3xl font-bold text-emerald-700 font-mono-tabular">
              {stats ? stats.resolved : '—'}
            </div>
          </div>
          <div className="p-5 sm:p-6">
            <div className="text-xs sm:text-sm text-amber-700 font-medium">{t.statFollowUp}</div>
            <div className="mt-1.5 text-2xl sm:text-3xl font-bold text-amber-700 font-mono-tabular">
              {stats ? stats.underFollowUp : '—'}
            </div>
          </div>
          <div className="p-5 sm:p-6">
            <div className="text-xs sm:text-sm text-slate-600">{t.statPending}</div>
            <div className="mt-1.5 text-2xl sm:text-3xl font-bold text-slate-800 font-mono-tabular">
              {stats ? stats.pending : '—'}
            </div>
          </div>
        </div>
      </section>

      {/* Quick Category Launch Grid */}
      <section className="max-w-[1200px] mx-auto px-4 sm:px-6">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3 pb-5 border-b border-slate-200">
          <div>
            <h2 className="font-display text-2xl font-bold text-slate-900 tracking-tight">
              {language === 'gu'
                ? 'કયા વિષયની સમસ્યા નોંધાવવી છે?'
                : language === 'hi'
                  ? 'किस विषय की समस्या दर्ज करनी है?'
                  : 'Report by Public Issue Category'}
            </h2>
            <p className="text-sm text-slate-600 mt-1">
              {language === 'gu'
                ? 'નીચેની કોઈપણ શ્રેણી પસંદ કરીને સીધું ફરિયાદ ફોર્મ ખોલો.'
                : language === 'hi'
                  ? 'नीचे दी गई किसी भी श्रेणी को चुनकर सीधे शिकायत फॉर्म खोलें।'
                  : 'Select any public service category below to open the complaint form pre-filled.'}
            </p>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('report')}
            className="text-sm font-semibold text-amber-700 hover:text-amber-800 whitespace-nowrap shrink-0 cursor-pointer"
          >
            {t.navReportCta} →
          </button>
        </div>

        <div className="mt-6 grid grid-cols-2 sm:grid-cols-4 gap-3.5">
          {FEATURED_CATEGORIES.map((cat) => {
            const Icon = cat.icon;
            const count = stats?.byCategory?.[cat.id] ?? 0;
            return (
              <button
                key={cat.id}
                type="button"
                onClick={() => onReportWithPreset({ category: cat.id })}
                className="group p-4 sm:p-5 rounded-xl bg-white border border-slate-200 hover:border-amber-500 text-left transition-all duration-150 hover:-translate-y-0.5 cursor-pointer flex flex-col justify-between gap-3"
              >
                <div className="flex items-center justify-between">
                  <div className="w-10 h-10 rounded-lg bg-slate-100 group-hover:bg-amber-50 text-slate-800 group-hover:text-amber-700 flex items-center justify-center transition-colors">
                    <Icon className="w-5 h-5" />
                  </div>
                  <span className="text-xs font-mono-tabular text-slate-400">
                    {count} {language === 'en' ? 'cases' : 'નોંધ'}
                  </span>
                </div>
                <div className="font-display font-semibold text-sm sm:text-base text-slate-900 group-hover:text-amber-800">
                  {CATEGORY_LABELS[language][cat.id]}
                </div>
              </button>
            );
          })}
        </div>
      </section>

      {/* Latest Constituency Updates */}
      <section className="max-w-[1200px] mx-auto px-4 sm:px-6">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 pb-6 border-b border-slate-200">
          <div>
            <h2 className="font-display text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
              {t.updatesHeading}
            </h2>
            <p className="mt-1.5 text-sm sm:text-base text-slate-600">{t.updatesSub}</p>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('issues')}
            className="text-sm font-semibold text-amber-700 hover:text-amber-800 whitespace-nowrap shrink-0 self-start sm:self-auto cursor-pointer"
          >
            {t.navIssues} →
          </button>
        </div>

        <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-6">
          {updates.map((u) => {
            const title =
              language === 'gu' ? u.titleGu : language === 'hi' ? u.titleHi : u.titleEn;
            const summary =
              language === 'gu' ? u.summaryGu : language === 'hi' ? u.summaryHi : u.summaryEn;
            const catLabel =
              CATEGORY_LABELS[language][u.category as ProblemCategory] || u.category;
            return (
              <article
                key={u.id}
                className="p-6 rounded-2xl bg-white border border-slate-200 hover:border-slate-300 transition-colors flex flex-col justify-between space-y-4"
              >
                <div className="space-y-2.5">
                  <div className="flex items-center gap-2 text-xs text-slate-500">
                    <span className="font-semibold text-amber-700">
                      {getLocalizedVillage(u.village)}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span>{catLabel}</span>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono-tabular">
                      {new Date(u.publishedAt).toLocaleDateString('en-IN', {
                        day: '2-digit',
                        month: 'short',
                        year: 'numeric',
                      })}
                    </span>
                  </div>
                  <h3 className="font-display text-lg font-semibold text-slate-900 leading-snug">
                    {title}
                  </h3>
                  <p className="text-sm text-slate-600 leading-relaxed">{summary}</p>
                </div>
              </article>
            );
          })}
        </div>
      </section>

      {/* 96 Villages Directory */}
      <section className="max-w-[1200px] mx-auto px-4 sm:px-6">
        <div className="p-6 sm:p-8 rounded-2xl bg-white border border-slate-200 space-y-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-5 border-b border-slate-100">
            <div>
              <h2 className="font-display text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
                {language === 'gu'
                  ? 'વાઘોડિયા તાલુકાના ૯૬ ગામો'
                  : language === 'hi'
                    ? 'वाघोडिया तालुका के 96 गांव'
                    : 'All 96 Villages of Waghodia Taluka'}
              </h2>
              <p className="text-sm text-slate-600 mt-1">
                {language === 'gu'
                  ? 'તમારા ગામ પર ક્લિક કરીને જાહેર પ્રશ્નો જુઓ અથવા નવી ફરિયાદ નોંધાવો.'
                  : language === 'hi'
                    ? 'अपने गांव पर क्लिक करके सार्वजनिक मुद्दे देखें या नई शिकायत दर्ज करें।'
                    : 'Search and tap your village to inspect public issues or report a local grievance.'}
              </p>
            </div>
            <div className="flex items-center gap-2 px-3 min-h-[42px] rounded-xl border border-slate-300 bg-slate-50 w-full md:w-72">
              <Search className="w-4 h-4 text-slate-400 shrink-0" />
              <input
                type="text"
                value={villageQuery}
                onChange={(e) => setVillageQuery(e.target.value)}
                placeholder={
                  language === 'gu'
                    ? 'ગામનું નામ શોધો...'
                    : language === 'hi'
                      ? 'गांव का नाम खोजें...'
                      : 'Filter 96 villages...'
                }
                className="w-full text-sm bg-transparent text-slate-900 focus:outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2.5">
            {filteredVillages.map((v) => {
              const vStat = stats?.byVillage?.[v.id];
              return (
                <button
                  key={v.id}
                  type="button"
                  onClick={() => onViewVillageIssues(v.id)}
                  className="p-3 rounded-xl border border-slate-200 bg-slate-50/70 hover:bg-amber-50/60 hover:border-amber-400 text-left transition-colors cursor-pointer"
                >
                  <div className="font-medium text-sm text-slate-900 truncate">
                    {language === 'gu' ? v.nameGu : language === 'hi' ? v.nameHi : v.nameEn}
                  </div>
                  <div className="mt-0.5 flex items-center justify-between text-[11px] text-slate-500">
                    <span className="truncate">{language !== 'en' ? v.nameEn : v.nameGu}</span>
                    {vStat && (
                      <span className="font-mono-tabular font-semibold text-amber-700 shrink-0 ml-1">
                        {vStat.total}
                      </span>
                    )}
                  </div>
                </button>
              );
            })}
          </div>

          {!villageQuery.trim() && (
            <div className="pt-2 flex justify-center">
              <button
                type="button"
                onClick={() => setShowAllVillages((prev) => !prev)}
                className="min-h-[42px] px-5 py-2 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-xs sm:text-sm font-semibold text-slate-800 transition-colors cursor-pointer"
              >
                {showAllVillages
                  ? language === 'gu'
                    ? 'ઓછા ગામો બતાવો'
                    : language === 'hi'
                      ? 'कम गांव दिखाएं'
                      : 'Show Fewer Villages'
                  : language === 'gu'
                    ? 'બધા ૯૬ ગામો જુઓ'
                    : language === 'hi'
                      ? 'सभी 96 गांव देखें'
                      : 'Show All 96 Villages'}
              </button>
            </div>
          )}
        </div>
      </section>

      {/* About & Contact Split */}
      <section id="about-contact" className="max-w-[1200px] mx-auto px-4 sm:px-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          <div className="lg:col-span-7 space-y-6 p-6 sm:p-8 rounded-2xl bg-white border border-slate-200">
            <div className="space-y-2">
              <h2 className="font-display text-2xl font-bold text-slate-900 tracking-tight">
                {t.aboutHeading}
              </h2>
              <p className="text-sm sm:text-base text-slate-600 leading-relaxed">{t.aboutBody}</p>
            </div>

            <div className="divide-y divide-slate-100 border-t border-slate-100">
              <div className="py-4 flex items-start gap-3.5">
                <ShieldCheck className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" />
                <div>
                  <h3 className="text-sm font-semibold text-slate-900">{t.aboutPoint1Title}</h3>
                  <p className="text-sm text-slate-600 mt-0.5">{t.aboutPoint1Body}</p>
                </div>
              </div>
              <div className="py-4 flex items-start gap-3.5">
                <Clock className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
                <div>
                  <h3 className="text-sm font-semibold text-slate-900">{t.aboutPoint2Title}</h3>
                  <p className="text-sm text-slate-600 mt-0.5">{t.aboutPoint2Body}</p>
                </div>
              </div>
              <div className="py-4 flex items-start gap-3.5">
                <CheckCircle2 className="w-5 h-5 text-slate-800 shrink-0 mt-0.5" />
                <div>
                  <h3 className="text-sm font-semibold text-slate-900">{t.aboutPoint3Title}</h3>
                  <p className="text-sm text-slate-600 mt-0.5">{t.aboutPoint3Body}</p>
                </div>
              </div>
              <div className="py-4 flex items-start gap-3.5">
                <Users className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
                <div>
                  <h3 className="text-sm font-semibold text-slate-900">
                    {language === 'gu'
                      ? '૯૬ ગામોની સમર્પિત ટીમ'
                      : language === 'hi'
                        ? '96 गांवों की समर्पित टीम'
                        : 'Dedicated 96-Village Field Network'}
                  </h3>
                  <p className="text-sm text-slate-600 mt-0.5">
                    {language === 'gu'
                      ? 'તાલુકાના દરેક ગામની ફરિયાદ સીધી જવાબદાર અધિકારી સુધી પહોંચે છે.'
                      : language === 'hi'
                        ? 'तालुका के हर गांव की शिकायत सीधे जिम्मेदार अधिकारी तक पहुंचती है।'
                        : 'Every village grievance is routed directly to assigned field coordinators for site verification.'}
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-5 p-6 sm:p-8 rounded-2xl bg-slate-900 text-slate-100 space-y-6">
            <h2 className="font-display text-xl sm:text-2xl font-bold tracking-tight text-white">
              {t.contactHeading}
            </h2>
            <div className="space-y-4 text-sm text-slate-300">
              <div className="flex items-start gap-3">
                <Building2 className="w-4 h-4 text-amber-400 shrink-0 mt-1" />
                <span>{t.contactOffice}</span>
              </div>
              <div className="flex items-start gap-3">
                <Clock className="w-4 h-4 text-amber-400 shrink-0 mt-1" />
                <span>{t.contactHours}</span>
              </div>
              <div className="flex items-start gap-3">
                <Phone className="w-4 h-4 text-amber-400 shrink-0 mt-1" />
                <span className="font-mono-tabular">{t.contactHelpline}</span>
              </div>
              <div className="flex items-start gap-3">
                <Mail className="w-4 h-4 text-amber-400 shrink-0 mt-1" />
                <span>{t.contactEmail}</span>
              </div>
              <div className="flex items-start gap-3">
                <MapPin className="w-4 h-4 text-amber-400 shrink-0 mt-1" />
                <span>Vaghodia Taluka · 96 Villages · Vadodara District, Gujarat</span>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-800 flex flex-wrap gap-3">
              <button
                type="button"
                onClick={() => onNavigate('report')}
                className="min-h-[44px] px-5 py-2.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 text-sm font-bold transition-colors cursor-pointer"
              >
                {t.navReportCta}
              </button>
              <button
                type="button"
                onClick={() => onNavigate('vision')}
                className="min-h-[44px] px-4 py-2.5 rounded-lg border border-slate-700 hover:bg-slate-800 text-slate-200 text-sm font-medium transition-colors cursor-pointer"
              >
                {t.navVision}
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
