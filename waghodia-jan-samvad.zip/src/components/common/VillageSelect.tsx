import React, { useEffect, useMemo, useRef, useState } from 'react';
import { ChevronDown, MapPin, Search, X } from 'lucide-react';
import { WAGHODIA_VILLAGES } from '../../data/waghodia.ts';
import { Language } from '../../types/index.ts';

interface VillageSelectProps {
  value: string;
  onChange: (villageId: string) => void;
  language: Language;
  includeAllOption?: boolean;
  allLabel?: string;
}

export const VillageSelect: React.FC<VillageSelectProps> = ({
  value,
  onChange,
  language,
  includeAllOption = false,
  allLabel = 'All Villages',
}) => {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener('mousedown', handleOutside);
    return () => document.removeEventListener('mousedown', handleOutside);
  }, []);

  const getDisplayName = (vId: string) => {
    if (vId === 'all') return allLabel;
    const found = WAGHODIA_VILLAGES.find((v) => v.id === vId);
    if (!found) return vId;
    return language === 'gu'
      ? `${found.nameGu} (${found.nameEn})`
      : language === 'hi'
        ? `${found.nameHi} (${found.nameEn})`
        : found.nameEn;
  };

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return WAGHODIA_VILLAGES;
    return WAGHODIA_VILLAGES.filter(
      (v) =>
        v.nameEn.toLowerCase().includes(q) ||
        v.nameGu.includes(q) ||
        v.nameHi.includes(q)
    );
  }, [query]);

  return (
    <div ref={containerRef} className="relative">
      <button
        type="button"
        onClick={() => setOpen((prev) => !prev)}
        className="w-full min-h-[46px] px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white hover:border-slate-400 text-left text-sm text-slate-900 flex items-center justify-between gap-2 transition-colors cursor-pointer"
      >
        <span className="flex items-center gap-2 truncate">
          <MapPin className="w-4 h-4 text-amber-600 shrink-0" />
          <span className="truncate font-medium">{getDisplayName(value)}</span>
        </span>
        <ChevronDown className={`w-4 h-4 text-slate-400 shrink-0 transition-transform ${open ? 'rotate-180' : ''}`} />
      </button>

      {open && (
        <div className="absolute left-0 right-0 mt-1.5 z-50 rounded-xl bg-white border border-slate-200 shadow-lg overflow-hidden">
          <div className="p-2 border-b border-slate-100 flex items-center gap-2 bg-slate-50">
            <Search className="w-4 h-4 text-slate-400 shrink-0" />
            <input
              type="text"
              autoFocus
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={
                language === 'gu'
                  ? '૯૬ ગામોમાંથી શોધો...'
                  : language === 'hi'
                    ? '96 गांवों में खोजें...'
                    : 'Search 96 villages...'
              }
              className="w-full py-1 text-sm bg-transparent text-slate-900 focus:outline-none"
            />
            {query && (
              <button
                type="button"
                onClick={() => setQuery('')}
                className="p-1 text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          <div className="max-h-64 overflow-y-auto divide-y divide-slate-50">
            {includeAllOption && (
              <button
                type="button"
                onClick={() => {
                  onChange('all');
                  setOpen(false);
                  setQuery('');
                }}
                className={`w-full text-left px-3.5 py-2.5 text-sm transition-colors cursor-pointer ${
                  value === 'all' ? 'bg-amber-50 text-amber-800 font-semibold' : 'hover:bg-slate-50 text-slate-700'
                }`}
              >
                {allLabel}
              </button>
            )}
            {filtered.length === 0 ? (
              <div className="px-3.5 py-4 text-xs text-slate-500 text-center">
                No matching village found
              </div>
            ) : (
              filtered.map((v) => {
                const isSelected = value === v.id;
                return (
                  <button
                    key={v.id}
                    type="button"
                    onClick={() => {
                      onChange(v.id);
                      setOpen(false);
                      setQuery('');
                    }}
                    className={`w-full text-left px-3.5 py-2.5 text-sm flex items-center justify-between gap-2 transition-colors cursor-pointer ${
                      isSelected
                        ? 'bg-amber-50 text-amber-900 font-semibold'
                        : 'hover:bg-slate-50 text-slate-800'
                    }`}
                  >
                    <span>
                      {language === 'gu'
                        ? v.nameGu
                        : language === 'hi'
                          ? v.nameHi
                          : v.nameEn}
                    </span>
                    {language !== 'en' && (
                      <span className="text-xs text-slate-400">{v.nameEn}</span>
                    )}
                  </button>
                );
              })
            )}
          </div>
        </div>
      )}
    </div>
  );
};
