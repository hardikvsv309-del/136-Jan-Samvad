import React, { useCallback, useEffect, useState } from 'react';
import {
  AdvancedMarker,
  InfoWindow,
  Map as GoogleMap,
  Pin,
  useAdvancedMarkerRef,
} from '@vis.gl/react-google-maps';
import { WAGHODIA_CENTER } from '../../data/waghodia.ts';
import { CATEGORY_LABELS, STATUS_LABELS } from '../../i18n/translations.ts';
import { ComplaintStatus, Language, MapIssuePoint } from '../../types/index.ts';

interface PublicIssuesMapProps {
  issues: MapIssuePoint[];
  language: Language;
  selectedIssueId: number | null;
  onSelectIssue: (issue: MapIssuePoint | null) => void;
  onTrackIssue: (code: string) => void;
}

const PIN_STYLES: Record<ComplaintStatus, { bg: string; border: string; glyph: string }> = {
  resolved: { bg: '#047857', border: '#064E3B', glyph: '#ECFDF5' },
  in_progress: { bg: '#D97706', border: '#92400E', glyph: '#FFFBEB' },
  verified: { bg: '#2563EB', border: '#1E40AF', glyph: '#EFF6FF' },
  submitted: { bg: '#DC2626', border: '#991B1B', glyph: '#FEF2F2' },
};

const IssueMarkerItem: React.FC<{
  issue: MapIssuePoint;
  isSelected: boolean;
  language: Language;
  onSelect: () => void;
  onClose: () => void;
  onTrackIssue: (code: string) => void;
}> = ({ issue, isSelected, language, onSelect, onClose, onTrackIssue }) => {
  const [markerRef, marker] = useAdvancedMarkerRef();
  const palette = PIN_STYLES[issue.status] || PIN_STYLES.submitted;

  return (
    <>
      <AdvancedMarker
        ref={markerRef}
        position={{ lat: issue.latitude, lng: issue.longitude }}
        onClick={onSelect}
        title={`${issue.complaintCode} · ${issue.village}`}
      >
        <Pin
          background={palette.bg}
          borderColor={palette.border}
          glyphColor={palette.glyph}
          scale={isSelected ? 1.25 : 1}
        />
      </AdvancedMarker>
      {isSelected && marker && (
        <InfoWindow anchor={marker} maxWidth={260} onCloseClick={onClose}>
          <div className="p-1 text-slate-900 space-y-1.5">
            <div className="flex items-center gap-1.5 text-[11px] font-mono-tabular text-slate-500">
              <span>{issue.complaintCode}</span>
              <span aria-hidden="true">·</span>
              <span>{issue.village}</span>
            </div>
            <p className="text-sm font-semibold leading-snug text-slate-900">{issue.title}</p>
            <div className="text-xs text-slate-600">
              {CATEGORY_LABELS[language][issue.category]} · {STATUS_LABELS[language][issue.status]}
            </div>
            <button
              type="button"
              onClick={() => onTrackIssue(issue.complaintCode)}
              className="mt-1 inline-flex items-center text-xs font-semibold text-amber-700 hover:text-amber-800 underline"
            >
              {language === 'gu'
                ? 'પ્રગતિ જુઓ →'
                : language === 'hi'
                  ? 'प्रगति देखें →'
                  : 'Track Progress →'}
            </button>
          </div>
        </InfoWindow>
      )}
    </>
  );
};

export const PublicIssuesMap: React.FC<PublicIssuesMapProps> = ({
  issues,
  language,
  selectedIssueId,
  onSelectIssue,
  onTrackIssue,
}) => {
  const [camera, setCamera] = useState({ center: WAGHODIA_CENTER, zoom: 11 });

  useEffect(() => {
    if (selectedIssueId) {
      const target = issues.find((i) => i.id === selectedIssueId);
      if (target) {
        setCamera({
          center: { lat: target.latitude, lng: target.longitude },
          zoom: 13,
        });
      }
    }
  }, [selectedIssueId, issues]);

  const handleClose = useCallback(() => {
    onSelectIssue(null);
  }, [onSelectIssue]);

  return (
    <div className="w-full h-[420px] rounded-xl overflow-hidden border border-slate-200 bg-slate-100">
      <GoogleMap
        mapId="DEMO_MAP_ID"
        center={camera.center}
        zoom={camera.zoom}
        onCameraChanged={(ev) => setCamera({ center: ev.detail.center, zoom: ev.detail.zoom })}
        gestureHandling="greedy"
        internalUsageAttributionIds={['gmp_mcp_codeassist_v1_aistudio']}
        style={{ width: '100%', height: '100%' }}
      >
        {issues.map((issue) => (
          <IssueMarkerItem
            key={issue.id}
            issue={issue}
            isSelected={selectedIssueId === issue.id}
            language={language}
            onSelect={() => onSelectIssue(issue)}
            onClose={handleClose}
            onTrackIssue={onTrackIssue}
          />
        ))}
      </GoogleMap>
    </div>
  );
};
