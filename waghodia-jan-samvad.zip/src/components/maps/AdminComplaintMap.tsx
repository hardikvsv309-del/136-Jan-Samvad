import React from 'react';
import { AdvancedMarker, Map as GoogleMap, Pin } from '@vis.gl/react-google-maps';

interface AdminComplaintMapProps {
  latitude: number;
  longitude: number;
  title: string;
}

export const AdminComplaintMap: React.FC<AdminComplaintMapProps> = ({
  latitude,
  longitude,
  title,
}) => {
  return (
    <div className="w-full h-[220px] rounded-xl overflow-hidden border border-slate-200 bg-slate-100">
      <GoogleMap
        mapId="DEMO_MAP_ID"
        center={{ lat: latitude, lng: longitude }}
        defaultZoom={15}
        gestureHandling="cooperative"
        internalUsageAttributionIds={['gmp_mcp_codeassist_v1_aistudio']}
        style={{ width: '100%', height: '100%' }}
      >
        <AdvancedMarker position={{ lat: latitude, lng: longitude }} title={title}>
          <Pin background="#0F172A" borderColor="#020617" glyphColor="#F59E0B" />
        </AdvancedMarker>
      </GoogleMap>
    </div>
  );
};
