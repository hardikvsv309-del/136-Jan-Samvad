import React, { useCallback, useEffect, useState } from 'react';
import { AdvancedMarker, Map as GoogleMap, MapMouseEvent, Pin } from '@vis.gl/react-google-maps';

interface LocationPickerMapProps {
  latitude: number;
  longitude: number;
  onLocationChange: (lat: number, lng: number) => void;
}

export const LocationPickerMap: React.FC<LocationPickerMapProps> = ({
  latitude,
  longitude,
  onLocationChange,
}) => {
  const [center, setCenter] = useState({ lat: latitude, lng: longitude });

  useEffect(() => {
    setCenter({ lat: latitude, lng: longitude });
  }, [latitude, longitude]);

  const handleMapClick = useCallback(
    (ev: MapMouseEvent) => {
      if (ev.detail.latLng) {
        onLocationChange(
          Number(ev.detail.latLng.lat.toFixed(6)),
          Number(ev.detail.latLng.lng.toFixed(6))
        );
      }
    },
    [onLocationChange]
  );

  return (
    <div className="w-full h-[280px] sm:h-[320px] rounded-xl overflow-hidden border border-slate-200 bg-slate-100">
      <GoogleMap
        mapId="DEMO_MAP_ID"
        center={center}
        defaultZoom={13}
        gestureHandling="greedy"
        onCameraChanged={(ev) => setCenter(ev.detail.center)}
        onClick={handleMapClick}
        internalUsageAttributionIds={['gmp_mcp_codeassist_v1_aistudio']}
        style={{ width: '100%', height: '100%' }}
      >
        <AdvancedMarker
          position={{ lat: latitude, lng: longitude }}
          draggable
          onDragEnd={(e) => {
            if (e.latLng) {
              onLocationChange(
                Number(e.latLng.lat().toFixed(6)),
                Number(e.latLng.lng().toFixed(6))
              );
            }
          }}
        >
          <Pin background="#D97706" borderColor="#92400E" glyphColor="#FFFFFF" />
        </AdvancedMarker>
      </GoogleMap>
    </div>
  );
};
