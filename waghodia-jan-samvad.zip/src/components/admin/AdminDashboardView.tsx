import React, { useCallback, useEffect, useState } from 'react';
import { User, onAuthStateChanged, signInWithPopup, signOut } from 'firebase/auth';
import {
  BarChart3,
  CheckCircle2,
  DatabaseBackup,
  Download,
  FileSpreadsheet,
  Lock,
  LogOut,
  Mail,
  Megaphone,
  Printer,
  Search,
  ShieldAlert,
  Upload,
  Users,
  X,
} from 'lucide-react';
import { PROBLEM_CATEGORIES } from '../../data/waghodia.ts';
import { CATEGORY_LABELS, STATUS_LABELS } from '../../i18n/translations.ts';
import { auth, googleAuthProvider } from '../../lib/firebase.ts';
import {
  AdminAnalytics,
  AdminComplaint,
  ComplaintStatus,
  Language,
  ProblemCategory,
  TeamUser,
} from '../../types/index.ts';
import { SafeImage } from '../common/SafeImage.tsx';
import { VillageSelect } from '../common/VillageSelect.tsx';
import { AdminComplaintMap } from '../maps/AdminComplaintMap.tsx';

interface AdminDashboardViewProps {
  language: Language;
  onDataMutated: () => void;
}

type AdminSection = 'complaints' | 'analytics' | 'updates' | 'team';

export const AdminDashboardView: React.FC<AdminDashboardViewProps> = ({
  language,
  onDataMutated,
}) => {
  const [firebaseUser, setFirebaseUser] = useState<User | null>(null);
  const [idToken, setIdToken] = useState<string | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [teamProfile, setTeamProfile] = useState<TeamUser | null>(null);
  const [authError, setAuthError] = useState<string | null>(null);

  const [section, setSection] = useState<AdminSection>('complaints');
  const [complaints, setComplaints] = useState<AdminComplaint[]>([]);
  const [teamMembers, setTeamMembers] = useState<TeamUser[]>([]);
  const [analytics, setAnalytics] = useState<AdminAnalytics | null>(null);
  const [loadingData, setLoadingData] = useState(false);

  // Filters
  const [searchQ, setSearchQ] = useState('');
  const [filterVillage, setFilterVillage] = useState('all');
  const [filterCategory, setFilterCategory] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all');

  // Selected complaint editor
  const [selected, setSelected] = useState<AdminComplaint | null>(null);
  const [editStatus, setEditStatus] = useState<ComplaintStatus>('submitted');
  const [editPriority, setEditPriority] = useState('normal');
  const [editAssigneeName, setEditAssigneeName] = useState('');
  const [editInternalNotes, setEditInternalNotes] = useState('');
  const [editActionTaken, setEditActionTaken] = useState('');
  const [editResultSummary, setEditResultSummary] = useState('');
  const [editPublicNote, setEditPublicNote] = useState('');
  const [editShowcase, setEditShowcase] = useState(false);
  const [editBeforePhotos, setEditBeforePhotos] = useState<string[]>([]);
  const [editAfterPhotos, setEditAfterPhotos] = useState<string[]>([]);
  const [savingComplaint, setSavingComplaint] = useState(false);
  const [saveMessage, setSaveMessage] = useState<string | null>(null);

  // Report period mode
  const [reportMode, setReportMode] = useState<'monthly' | 'quarterly'>('monthly');

  // Publish update form
  const [updTitleEn, setUpdTitleEn] = useState('');
  const [updTitleGu, setUpdTitleGu] = useState('');
  const [updTitleHi, setUpdTitleHi] = useState('');
  const [updSummaryEn, setUpdSummaryEn] = useState('');
  const [updSummaryGu, setUpdSummaryGu] = useState('');
  const [updSummaryHi, setUpdSummaryHi] = useState('');
  const [updVillage, setUpdVillage] = useState('Vaghodia');
  const [updCategory, setUpdCategory] = useState<ProblemCategory>('roads');
  const [publishingUpdate, setPublishingUpdate] = useState(false);

  // Team invite form
  const [newMemberEmail, setNewMemberEmail] = useState('');
  const [newMemberName, setNewMemberName] = useState('');
  const [newMemberRole, setNewMemberRole] = useState('field_officer');
  const [newMemberArea, setNewMemberArea] = useState('All Villages');
  const [addingMember, setAddingMember] = useState(false);

  const authFetch = useCallback(
    async (url: string, init?: RequestInit) => {
      if (!firebaseUser) throw new Error('Not signed in');
      const freshToken = await firebaseUser.getIdToken();
      setIdToken(freshToken);
      const res = await fetch(url, {
        ...init,
        headers: {
          ...(init?.headers || {}),
          Authorization: `Bearer ${freshToken}`,
        },
      });
      return res;
    },
    [firebaseUser]
  );

  const loadProfileAndData = useCallback(
    async (user: User) => {
      setAuthLoading(true);
      setAuthError(null);
      try {
        const token = await user.getIdToken();
        setIdToken(token);
        const meRes = await fetch('/api/admin/me', {
          headers: { Authorization: `Bearer ${token}` },
        });
        const meData = await meRes.json();
        if (!meRes.ok) {
          throw new Error(meData.error || 'Authentication failed');
        }
        setTeamProfile(meData.teamUser);
      } catch (err: unknown) {
        setAuthError(err instanceof Error ? err.message : 'Unable to verify admin access.');
      } finally {
        setAuthLoading(false);
      }
    },
    []
  );

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (user) => {
      setFirebaseUser(user);
      if (user) {
        loadProfileAndData(user);
      } else {
        setIdToken(null);
        setTeamProfile(null);
        setAuthLoading(false);
      }
    });
    return () => unsub();
  }, [loadProfileAndData]);

  const fetchComplaints = useCallback(async () => {
    if (!firebaseUser || !teamProfile || teamProfile.role === 'pending' || !teamProfile.isActive) {
      return;
    }
    setLoadingData(true);
    try {
      const params = new URLSearchParams();
      if (filterVillage !== 'all') params.set('village', filterVillage);
      if (filterCategory !== 'all') params.set('category', filterCategory);
      if (filterStatus !== 'all') params.set('status', filterStatus);
      if (searchQ.trim()) params.set('q', searchQ.trim());

      const res = await authFetch(`/api/admin/complaints?${params.toString()}`);
      const data = await res.json();
      if (res.ok) {
        setComplaints(data.complaints || []);
      }
    } catch (err) {
      console.error('Admin complaints fetch failed:', err);
    } finally {
      setLoadingData(false);
    }
  }, [firebaseUser, teamProfile, filterVillage, filterCategory, filterStatus, searchQ, authFetch]);

  const fetchTeamAndAnalytics = useCallback(async () => {
    if (!firebaseUser || !teamProfile || teamProfile.role === 'pending' || !teamProfile.isActive) {
      return;
    }
    try {
      const [teamRes, analyticsRes] = await Promise.all([
        authFetch('/api/admin/team'),
        authFetch('/api/admin/analytics'),
      ]);
      if (teamRes.ok) {
        const tData = await teamRes.json();
        setTeamMembers(tData.team || []);
      }
      if (analyticsRes.ok) {
        const aData = await analyticsRes.json();
        setAnalytics(aData);
      }
    } catch (err) {
      console.error('Failed loading team/analytics:', err);
    }
  }, [firebaseUser, teamProfile, authFetch]);

  useEffect(() => {
    fetchComplaints();
  }, [fetchComplaints]);

  useEffect(() => {
    fetchTeamAndAnalytics();
  }, [fetchTeamAndAnalytics]);

  const handleSignIn = async () => {
    setAuthError(null);
    try {
      await signInWithPopup(auth, googleAuthProvider);
    } catch (err: unknown) {
      setAuthError(err instanceof Error ? err.message : 'Google Sign-In failed.');
    }
  };

  const handleSignOut = async () => {
    await signOut(auth);
    setSelected(null);
  };

  const openInspector = (c: AdminComplaint) => {
    setSelected(c);
    setEditStatus(c.status);
    setEditPriority(c.priority || 'normal');
    setEditAssigneeName(c.assignedToName || '');
    setEditInternalNotes(c.internalNotes || '');
    setEditActionTaken(c.actionTaken || '');
    setEditResultSummary(c.resultSummary || '');
    setEditShowcase(Boolean(c.isPublicShowcase));
    setEditBeforePhotos(c.beforePhotos || []);
    setEditAfterPhotos(c.afterPhotos || []);
    setEditPublicNote('');
    setSaveMessage(null);
  };

  const handleUploadBeforeAfter = async (
    target: 'before' | 'after',
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    const formData = new FormData();
    Array.from(files).forEach((f) => formData.append('files', f));
    try {
      const res = await fetch('/api/upload', { method: 'POST', body: formData });
      const data = await res.json();
      if (res.ok && Array.isArray(data.files)) {
        const urls = data.files.map((f: { url: string }) => f.url);
        if (target === 'before') {
          setEditBeforePhotos((prev) => [...prev, ...urls]);
        } else {
          setEditAfterPhotos((prev) => [...prev, ...urls]);
        }
      }
    } catch (err) {
      console.error('Photo upload error:', err);
    } finally {
      e.target.value = '';
    }
  };

  const handleSaveComplaint = async (overrideStatus?: ComplaintStatus) => {
    if (!selected) return;
    setSavingComplaint(true);
    setSaveMessage(null);
    const nextStatus = overrideStatus || editStatus;
    const matchedMember = teamMembers.find((m) => m.name === editAssigneeName);

    try {
      const res = await authFetch(`/api/admin/complaints/${selected.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          status: nextStatus,
          priority: editPriority,
          assignedToId: matchedMember ? matchedMember.id : selected.assignedToId,
          assignedToName: editAssigneeName,
          internalNotes: editInternalNotes,
          actionTaken: editActionTaken,
          resultSummary: editResultSummary,
          beforePhotos: editBeforePhotos,
          afterPhotos: editAfterPhotos,
          isPublicShowcase: editShowcase,
          publicTimelineNote: editPublicNote.trim() || undefined,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Update failed');

      setSelected(data.complaint);
      setEditStatus(data.complaint.status);
      setEditPublicNote('');
      setSaveMessage('Saved and broadcasted live update.');
      await fetchComplaints();
      await fetchTeamAndAnalytics();
      onDataMutated();
    } catch (err: unknown) {
      setSaveMessage(err instanceof Error ? err.message : 'Save failed.');
    } finally {
      setSavingComplaint(false);
    }
  };

  const handleDownloadWithAuth = async (url: string, filename: string) => {
    try {
      const res = await authFetch(url);
      if (!res.ok) throw new Error('Download failed');
      const blob = await res.blob();
      const objUrl = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = objUrl;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(objUrl);
      fetchTeamAndAnalytics();
    } catch (err) {
      console.error('Download failed:', err);
    }
  };

  const handlePublishUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!updTitleEn.trim() || !updSummaryEn.trim()) return;
    setPublishingUpdate(true);
    try {
      const res = await authFetch('/api/admin/updates', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          titleEn: updTitleEn.trim(),
          titleGu: updTitleGu.trim() || updTitleEn.trim(),
          titleHi: updTitleHi.trim() || updTitleEn.trim(),
          summaryEn: updSummaryEn.trim(),
          summaryGu: updSummaryGu.trim() || updSummaryEn.trim(),
          summaryHi: updSummaryHi.trim() || updSummaryEn.trim(),
          village: updVillage,
          category: updCategory,
        }),
      });
      if (res.ok) {
        setUpdTitleEn('');
        setUpdTitleGu('');
        setUpdTitleHi('');
        setUpdSummaryEn('');
        setUpdSummaryGu('');
        setUpdSummaryHi('');
        onDataMutated();
        fetchTeamAndAnalytics();
      }
    } finally {
      setPublishingUpdate(false);
    }
  };

  const handleAddTeamMember = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMemberEmail.trim()) return;
    setAddingMember(true);
    try {
      const res = await authFetch('/api/admin/team', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: newMemberEmail.trim(),
          name: newMemberName.trim(),
          role: newMemberRole,
          assignedArea: newMemberArea.trim() || 'All Villages',
        }),
      });
      if (res.ok) {
        setNewMemberEmail('');
        setNewMemberName('');
        fetchTeamAndAnalytics();
      }
    } finally {
      setAddingMember(false);
    }
  };

  const handleToggleMember = async (member: TeamUser, updates: Partial<TeamUser>) => {
    await authFetch(`/api/admin/team/${member.id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates),
    });
    fetchTeamAndAnalytics();
  };

  if (authLoading) {
    return (
      <div className="max-w-lg mx-auto px-4 py-20 text-center text-sm text-slate-600">
        Verifying constituency admin session...
      </div>
    );
  }

  if (!firebaseUser || !idToken) {
    return (
      <div className="max-w-md mx-auto px-4 py-16">
        <div className="p-8 rounded-2xl bg-white border border-slate-200 text-center space-y-5">
          <div className="w-12 h-12 rounded-full bg-slate-100 text-slate-800 flex items-center justify-center mx-auto">
            <Lock className="w-6 h-6" />
          </div>
          <div className="space-y-1.5">
            <h1 className="font-display text-2xl font-bold text-slate-900">
              Authorized Team Portal
            </h1>
            <p className="text-sm text-slate-600">
              Sign in with your authorized Google account to manage Waghodia constituency grievances,
              assign field officers, and export reports.
            </p>
          </div>
          {authError && (
            <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-xs text-red-700">
              {authError}
            </div>
          )}
          <button
            type="button"
            onClick={handleSignIn}
            className="w-full min-h-[46px] px-5 py-2.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white text-sm font-semibold transition-colors cursor-pointer"
          >
            Sign in with Google
          </button>
        </div>
      </div>
    );
  }

  if (teamProfile && (teamProfile.role === 'pending' || !teamProfile.isActive)) {
    return (
      <div className="max-w-md mx-auto px-4 py-16">
        <div className="p-8 rounded-2xl bg-white border border-slate-200 text-center space-y-4">
          <ShieldAlert className="w-10 h-10 text-amber-600 mx-auto" />
          <h2 className="font-display text-xl font-bold text-slate-900">
            Authorization Pending
          </h2>
          <p className="text-sm text-slate-600">
            Signed in as <span className="font-medium text-slate-900">{teamProfile.email}</span>.
            Ask the Constituency Super Admin to activate your role in Team Management.
          </p>
          <button
            type="button"
            onClick={handleSignOut}
            className="min-h-[42px] px-5 py-2 rounded-lg border border-slate-300 text-sm font-medium text-slate-700 hover:bg-slate-50 cursor-pointer"
          >
            Sign Out
          </button>
        </div>
      </div>
    );
  }

  const reportPeriods = reportMode === 'monthly' ? analytics?.monthly || [] : analytics?.quarterly || [];
  const maxPeriodCount = Math.max(1, ...reportPeriods.map((p) => p.total));

  return (
    <div className="max-w-[1360px] mx-auto px-4 sm:px-6 py-6 sm:py-8">
      {/* Top Admin Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-200 no-print">
        <div>
          <div className="text-xs text-slate-500 font-mono-tabular">
            {teamProfile?.name} · {teamProfile?.role} · {teamProfile?.email}
          </div>
          <h1 className="font-display text-2xl font-bold text-slate-900 tracking-tight mt-0.5">
            Waghodia Jan Samvad — Admin Console
          </h1>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            onClick={() =>
              handleDownloadWithAuth(
                `/api/admin/export-csv?village=${filterVillage}&category=${filterCategory}&status=${filterStatus}`,
                `waghodia-complaints-${new Date().toISOString().slice(0, 10)}.csv`
              )
            }
            className="inline-flex items-center gap-1.5 min-h-[40px] px-3.5 py-2 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-xs font-semibold text-slate-800 whitespace-nowrap cursor-pointer"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-700" />
            <span>Export CSV</span>
          </button>

          <button
            type="button"
            onClick={() =>
              handleDownloadWithAuth(
                '/api/admin/backup',
                `waghodia-db-backup-${new Date().toISOString().slice(0, 10)}.json`
              )
            }
            className="inline-flex items-center gap-1.5 min-h-[40px] px-3.5 py-2 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-xs font-semibold text-slate-800 whitespace-nowrap cursor-pointer"
          >
            <DatabaseBackup className="w-4 h-4 text-amber-700" />
            <span>DB Backup</span>
          </button>

          <button
            type="button"
            onClick={handleSignOut}
            className="inline-flex items-center gap-1.5 min-h-[40px] px-3.5 py-2 rounded-lg bg-slate-900 hover:bg-slate-800 text-xs font-semibold text-white whitespace-nowrap cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Sign Out</span>
          </button>
        </div>
      </div>

      {/* Admin Sub-Navigation */}
      <div className="mt-5 flex flex-wrap gap-1.5 p-1 bg-slate-100 rounded-xl w-fit no-print">
        {(
          [
            { id: 'complaints', label: 'Complaints Queue', icon: Search },
            { id: 'analytics', label: 'Charts & Reports', icon: BarChart3 },
            { id: 'updates', label: 'Updates & Audit Logs', icon: Megaphone },
            { id: 'team', label: 'Team & Roles', icon: Users },
          ] as const
        ).map((tab) => {
          const Icon = tab.icon;
          const active = section === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => setSection(tab.id)}
              className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg text-xs sm:text-sm font-medium transition-colors whitespace-nowrap cursor-pointer ${
                active
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* SECTION 1: COMPLAINTS QUEUE */}
      {section === 'complaints' && (
        <div className="mt-6 space-y-5">
          {/* Search & Filters */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            <div className="flex items-center gap-2 px-3 min-h-[42px] rounded-lg border border-slate-300 bg-white">
              <Search className="w-4 h-4 text-slate-400 shrink-0" />
              <input
                type="text"
                value={searchQ}
                onChange={(e) => setSearchQ(e.target.value)}
                placeholder="Search ID, name, mobile, title..."
                className="w-full text-sm text-slate-900 focus:outline-none"
              />
            </div>

            <VillageSelect
              value={filterVillage}
              onChange={setFilterVillage}
              language="en"
              includeAllOption
              allLabel="All 96 Villages"
            />

            <select
              value={filterCategory}
              onChange={(e) => setFilterCategory(e.target.value)}
              className="min-h-[42px] px-3 rounded-lg border border-slate-300 bg-white text-sm text-slate-900"
            >
              <option value="all">All Categories</option>
              {PROBLEM_CATEGORIES.map((c) => (
                <option key={c} value={c}>
                  {CATEGORY_LABELS.en[c]}
                </option>
              ))}
            </select>

            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="min-h-[42px] px-3 rounded-lg border border-slate-300 bg-white text-sm text-slate-900"
            >
              <option value="all">All Statuses</option>
              {(['submitted', 'verified', 'in_progress', 'resolved'] as ComplaintStatus[]).map(
                (st) => (
                  <option key={st} value={st}>
                    {STATUS_LABELS.en[st]}
                  </option>
                )
              )}
            </select>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* Data Table */}
            <div
              className={`${
                selected ? 'lg:col-span-7' : 'lg:col-span-12'
              } rounded-xl bg-white border border-slate-200 overflow-hidden`}
            >
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600">
                      <th className="py-3 px-4">ID</th>
                      <th className="py-3 px-4">Citizen & Village</th>
                      <th className="py-3 px-4">Issue</th>
                      <th className="py-3 px-4">Assigned</th>
                      <th className="py-3 px-4">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-sm">
                    {loadingData ? (
                      <tr>
                        <td colSpan={5} className="py-8 text-center text-slate-500">
                          Loading grievances...
                        </td>
                      </tr>
                    ) : complaints.length === 0 ? (
                      <tr>
                        <td colSpan={5} className="py-8 text-center text-slate-500">
                          No complaints found for these filters.
                        </td>
                      </tr>
                    ) : (
                      complaints.map((c) => (
                        <tr
                          key={c.id}
                          onClick={() => openInspector(c)}
                          className={`cursor-pointer transition-colors ${
                            selected?.id === c.id ? 'bg-amber-50/70' : 'hover:bg-slate-50'
                          }`}
                        >
                          <td className="py-3 px-4 font-mono-tabular text-xs font-semibold text-slate-900 whitespace-nowrap">
                            {c.complaintCode}
                          </td>
                          <td className="py-3 px-4">
                            <div className="font-medium text-slate-900">{c.citizenName}</div>
                            <div className="text-xs text-slate-500 font-mono-tabular">
                              {c.mobileNumber} · {c.village}
                            </div>
                          </td>
                          <td className="py-3 px-4 max-w-[260px]">
                            <div className="font-medium text-slate-900 truncate">{c.title}</div>
                            <div className="text-xs text-slate-500">
                              {CATEGORY_LABELS[language][c.category] || c.category}
                            </div>
                          </td>
                          <td className="py-3 px-4 text-xs text-slate-600 whitespace-nowrap">
                            {c.assignedToName || 'Unassigned'}
                          </td>
                          <td className="py-3 px-4 text-xs font-semibold whitespace-nowrap">
                            <span
                              className={
                                c.status === 'resolved'
                                  ? 'text-emerald-700'
                                  : c.status === 'in_progress'
                                    ? 'text-amber-700'
                                    : c.status === 'verified'
                                      ? 'text-blue-700'
                                      : 'text-red-700'
                              }
                            >
                              {STATUS_LABELS.en[c.status]}
                            </span>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Complaint Inspector Drawer */}
            {selected && (
              <div className="lg:col-span-5 rounded-xl bg-white border border-slate-200 p-5 sm:p-6 space-y-5">
                <div className="flex items-start justify-between gap-3 pb-4 border-b border-slate-100">
                  <div>
                    <div className="text-xs font-mono-tabular font-semibold text-amber-700">
                      {selected.complaintCode} · {selected.village}
                    </div>
                    <h2 className="font-display text-lg font-bold text-slate-900 mt-0.5">
                      {selected.title}
                    </h2>
                  </div>
                  <button
                    type="button"
                    onClick={() => setSelected(null)}
                    className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 cursor-pointer"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                {/* Private Citizen Info */}
                <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-200 text-xs space-y-1">
                  <div className="font-semibold text-slate-900">
                    Citizen: {selected.citizenName}
                  </div>
                  <div className="font-mono-tabular text-slate-700">
                    Mobile: {selected.mobileNumber}
                    {selected.citizenEmail ? ` · ${selected.citizenEmail}` : ''}
                  </div>
                  <div className="text-slate-600">Location Note: {selected.locationLabel}</div>
                </div>

                <p className="text-sm text-slate-700 leading-relaxed">{selected.description}</p>

                {/* Citizen Uploaded Photos/Videos */}
                {selected.mediaUrls && selected.mediaUrls.length > 0 && (
                  <div className="space-y-2">
                    <div className="text-xs font-semibold text-slate-600">
                      Citizen Attachments ({selected.mediaUrls.length})
                    </div>
                    <div className="grid grid-cols-2 gap-2.5">
                      {selected.mediaUrls.map((m) =>
                        m.type === 'video' ? (
                          <video
                            key={m.url}
                            src={m.url}
                            controls
                            className="w-full rounded-lg border border-slate-200 aspect-[4/3] bg-black"
                          />
                        ) : (
                          <a
                            key={m.url}
                            href={m.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="block rounded-lg overflow-hidden border border-slate-200 aspect-[4/3]"
                          >
                            <SafeImage
                              src={m.url}
                              alt={m.name}
                              className="w-full h-full object-cover"
                            />
                          </a>
                        )
                      )}
                    </div>
                  </div>
                )}

                {/* Exact GPS Map */}
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs text-slate-500">
                    <span>Exact Complaint Coordinates</span>
                    <span className="font-mono-tabular">
                      {selected.latitude.toFixed(5)}, {selected.longitude.toFixed(5)}
                    </span>
                  </div>
                  <AdminComplaintMap
                    latitude={selected.latitude}
                    longitude={selected.longitude}
                    title={selected.complaintCode}
                  />
                </div>

                {/* Action & Status Controls */}
                <div className="space-y-3.5 pt-2 border-t border-slate-100">
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-medium text-slate-600 mb-1">
                        Status
                      </label>
                      <select
                        value={editStatus}
                        onChange={(e) => setEditStatus(e.target.value as ComplaintStatus)}
                        className="w-full min-h-[40px] px-2.5 rounded-lg border border-slate-300 text-sm bg-white"
                      >
                        <option value="submitted">Submitted</option>
                        <option value="verified">Verified</option>
                        <option value="in_progress">Follow-up / Action Taken</option>
                        <option value="resolved">Resolved</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-slate-600 mb-1">
                        Assign Officer
                      </label>
                      <select
                        value={editAssigneeName}
                        onChange={(e) => setEditAssigneeName(e.target.value)}
                        className="w-full min-h-[40px] px-2.5 rounded-lg border border-slate-300 text-sm bg-white"
                      >
                        <option value="">Unassigned</option>
                        {teamMembers
                          .filter((m) => m.isActive && m.role !== 'pending')
                          .map((m) => (
                            <option key={m.id} value={m.name}>
                              {m.name} ({m.role})
                            </option>
                          ))}
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-600 mb-1">
                      Priority
                    </label>
                    <select
                      value={editPriority}
                      onChange={(e) => setEditPriority(e.target.value)}
                      className="w-full min-h-[40px] px-2.5 rounded-lg border border-slate-300 text-sm bg-white"
                    >
                      <option value="normal">Normal</option>
                      <option value="high">High</option>
                      <option value="urgent">Urgent</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-600 mb-1">
                      Internal Team Notes (Private — never shown publicly)
                    </label>
                    <textarea
                      rows={2}
                      value={editInternalNotes}
                      onChange={(e) => setEditInternalNotes(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-600 mb-1">
                      Follow-up / Action Taken (Public)
                    </label>
                    <textarea
                      rows={2}
                      value={editActionTaken}
                      onChange={(e) => setEditActionTaken(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-600 mb-1">
                      Result Summary (Public / Our Work)
                    </label>
                    <textarea
                      rows={2}
                      value={editResultSummary}
                      onChange={(e) => setEditResultSummary(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-600 mb-1">
                      Append Public Timeline Update Note
                    </label>
                    <input
                      type="text"
                      value={editPublicNote}
                      onChange={(e) => setEditPublicNote(e.target.value)}
                      placeholder="e.g. Site engineer inspected and work order issued"
                      className="w-full min-h-[38px] px-3 rounded-lg border border-slate-300 text-xs"
                    />
                  </div>

                  {/* Before / After Uploads */}
                  <div className="grid grid-cols-2 gap-3 pt-1">
                    <div>
                      <label className="block text-xs font-medium text-slate-600 mb-1">
                        Before Photos ({editBeforePhotos.length})
                      </label>
                      <label className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-300 text-xs font-medium text-slate-700 hover:bg-slate-50 cursor-pointer w-full justify-center">
                        <Upload className="w-3.5 h-3.5" />
                        <span>Upload Before</span>
                        <input
                          type="file"
                          accept="image/*"
                          multiple
                          className="hidden"
                          onChange={(e) => handleUploadBeforeAfter('before', e)}
                        />
                      </label>
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-slate-600 mb-1">
                        After Photos ({editAfterPhotos.length})
                      </label>
                      <label className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-300 text-xs font-medium text-slate-700 hover:bg-slate-50 cursor-pointer w-full justify-center">
                        <Upload className="w-3.5 h-3.5" />
                        <span>Upload After</span>
                        <input
                          type="file"
                          accept="image/*"
                          multiple
                          className="hidden"
                          onChange={(e) => handleUploadBeforeAfter('after', e)}
                        />
                      </label>
                    </div>
                  </div>

                  <label className="flex items-center gap-2 text-xs font-medium text-slate-800 cursor-pointer pt-1">
                    <input
                      type="checkbox"
                      checked={editShowcase}
                      onChange={(e) => setEditShowcase(e.target.checked)}
                      className="w-4 h-4 rounded border-slate-300 text-emerald-700"
                    />
                    <span>Feature in &ldquo;Our Work&rdquo; Transparency Page (when Resolved)</span>
                  </label>

                  {saveMessage && (
                    <div className="p-2.5 rounded-lg bg-emerald-50 border border-emerald-200 text-xs text-emerald-800">
                      {saveMessage}
                    </div>
                  )}

                  <div className="flex flex-wrap gap-2.5 pt-2">
                    <button
                      type="button"
                      disabled={savingComplaint}
                      onClick={() => handleSaveComplaint()}
                      className="flex-1 min-h-[42px] px-4 py-2 rounded-lg bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold cursor-pointer"
                    >
                      {savingComplaint ? 'Saving...' : 'Save Changes'}
                    </button>
                    {editStatus !== 'resolved' && (
                      <button
                        type="button"
                        disabled={savingComplaint}
                        onClick={() => handleSaveComplaint('resolved')}
                        className="inline-flex items-center gap-1.5 min-h-[42px] px-4 py-2 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold cursor-pointer"
                      >
                        <CheckCircle2 className="w-4 h-4" />
                        <span>Mark Resolved</span>
                      </button>
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* SECTION 2: ANALYTICS & REPORTS */}
      {section === 'analytics' && (
        <div className="mt-6 space-y-6">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg">
              <button
                type="button"
                onClick={() => setReportMode('monthly')}
                className={`px-3.5 py-1.5 text-xs font-semibold rounded-md cursor-pointer ${
                  reportMode === 'monthly'
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-600'
                }`}
              >
                Monthly Report
              </button>
              <button
                type="button"
                onClick={() => setReportMode('quarterly')}
                className={`px-3.5 py-1.5 text-xs font-semibold rounded-md cursor-pointer ${
                  reportMode === 'quarterly'
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-600'
                }`}
              >
                Quarterly Report
              </button>
            </div>

            <div className="flex items-center gap-2.5 no-print">
              <button
                type="button"
                onClick={() => window.print()}
                className="inline-flex items-center gap-1.5 min-h-[40px] px-4 py-2 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-xs font-semibold text-slate-800 cursor-pointer"
              >
                <Printer className="w-4 h-4" />
                <span>Print Report</span>
              </button>
              <button
                type="button"
                onClick={() =>
                  handleDownloadWithAuth(
                    '/api/admin/export-csv',
                    `waghodia-${reportMode}-report.csv`
                  )
                }
                className="inline-flex items-center gap-1.5 min-h-[40px] px-4 py-2 rounded-lg bg-slate-900 text-white text-xs font-semibold cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>Download CSV</span>
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Period Trend Chart */}
            <div className="lg:col-span-7 p-6 rounded-xl bg-white border border-slate-200 space-y-5">
              <div className="flex items-center justify-between">
                <h2 className="font-display text-lg font-bold text-slate-900">
                  {reportMode === 'monthly' ? 'Monthly' : 'Quarterly'} Grievance Resolution
                </h2>
                <span className="text-xs font-mono-tabular text-slate-600">
                  Avg Resolution: {analytics?.avgResolutionDays ?? 0} days
                </span>
              </div>

              <div className="space-y-4">
                {reportPeriods.map((row) => (
                  <div key={row.period} className="space-y-1.5">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-mono-tabular font-semibold text-slate-800">
                        {row.period}
                      </span>
                      <span className="font-mono-tabular text-slate-600">
                        {row.resolved} resolved / {row.total} total
                      </span>
                    </div>
                    <div className="w-full h-3 rounded-full bg-slate-100 overflow-hidden flex">
                      <div
                        className="h-full bg-emerald-600"
                        style={{ width: `${(row.resolved / maxPeriodCount) * 100}%` }}
                      />
                      <div
                        className="h-full bg-amber-500"
                        style={{ width: `${(row.pending / maxPeriodCount) * 100}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Category Breakdown */}
            <div className="lg:col-span-5 p-6 rounded-xl bg-white border border-slate-200 space-y-4">
              <h2 className="font-display text-lg font-bold text-slate-900">By Category</h2>
              <div className="divide-y divide-slate-100">
                {Object.entries(analytics?.byCategory || {})
                  .sort((a, b) => Number(b[1]) - Number(a[1]))
                  .map(([cat, count]) => (
                    <div key={cat} className="py-2.5 flex items-center justify-between text-sm">
                      <span className="text-slate-700">
                        {CATEGORY_LABELS.en[cat as ProblemCategory] || cat}
                      </span>
                      <span className="font-mono-tabular font-semibold text-slate-900">
                        {count}
                      </span>
                    </div>
                  ))}
              </div>
            </div>
          </div>

          {/* Village Performance Table */}
          <div className="p-6 rounded-xl bg-white border border-slate-200 space-y-4">
            <h2 className="font-display text-lg font-bold text-slate-900">
              Village-Wise Resolution Summary
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              {Object.entries(analytics?.byVillage || {}).map(([village, vStats]) => (
                <div key={village} className="p-3.5 rounded-lg border border-slate-200 bg-slate-50">
                  <div className="text-sm font-semibold text-slate-900">{village}</div>
                  <div className="mt-1 text-xs font-mono-tabular text-slate-600">
                    {vStats.resolved} / {vStats.total} resolved
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* SECTION 3: UPDATES, EMAIL LOGS & AUDIT LOGS */}
      {section === 'updates' && (
        <div className="mt-6 grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Publish Public Update */}
          <form
            onSubmit={handlePublishUpdate}
            className="lg:col-span-5 p-6 rounded-xl bg-white border border-slate-200 space-y-4"
          >
            <h2 className="font-display text-lg font-bold text-slate-900">
              Publish Public Constituency Update
            </h2>
            <div className="grid grid-cols-2 gap-3">
              <VillageSelect
                value={updVillage}
                onChange={setUpdVillage}
                language="en"
              />
              <select
                value={updCategory}
                onChange={(e) => setUpdCategory(e.target.value as ProblemCategory)}
                className="min-h-[40px] px-3 rounded-lg border border-slate-300 text-sm bg-white"
              >
                {PROBLEM_CATEGORIES.map((c) => (
                  <option key={c} value={c}>
                    {CATEGORY_LABELS.en[c]}
                  </option>
                ))}
              </select>
            </div>
            <input
              type="text"
              required
              value={updTitleEn}
              onChange={(e) => setUpdTitleEn(e.target.value)}
              placeholder="Title (English) *"
              className="w-full min-h-[40px] px-3 rounded-lg border border-slate-300 text-sm"
            />
            <input
              type="text"
              value={updTitleGu}
              onChange={(e) => setUpdTitleGu(e.target.value)}
              placeholder="Title (Gujarati - ગુજરાતી)"
              className="w-full min-h-[40px] px-3 rounded-lg border border-slate-300 text-sm"
            />
            <input
              type="text"
              value={updTitleHi}
              onChange={(e) => setUpdTitleHi(e.target.value)}
              placeholder="Title (Hindi - हिन्दी)"
              className="w-full min-h-[40px] px-3 rounded-lg border border-slate-300 text-sm"
            />
            <textarea
              required
              rows={2}
              value={updSummaryEn}
              onChange={(e) => setUpdSummaryEn(e.target.value)}
              placeholder="Summary (English) *"
              className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm"
            />
            <textarea
              rows={2}
              value={updSummaryGu}
              onChange={(e) => setUpdSummaryGu(e.target.value)}
              placeholder="Summary (Gujarati)"
              className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm"
            />
            <textarea
              rows={2}
              value={updSummaryHi}
              onChange={(e) => setUpdSummaryHi(e.target.value)}
              placeholder="Summary (Hindi)"
              className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm"
            />
            <button
              type="submit"
              disabled={publishingUpdate}
              className="w-full min-h-[44px] rounded-lg bg-slate-900 hover:bg-slate-800 text-white text-sm font-semibold cursor-pointer"
            >
              {publishingUpdate ? 'Publishing...' : 'Publish Update'}
            </button>
          </form>

          {/* Audit & Email Notification Logs */}
          <div className="lg:col-span-7 space-y-6">
            <div className="p-6 rounded-xl bg-white border border-slate-200 space-y-3">
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-amber-700" />
                <h2 className="font-display text-lg font-bold text-slate-900">
                  Automated Email Notification Log
                </h2>
              </div>
              <div className="divide-y divide-slate-100 max-h-[220px] overflow-y-auto text-xs">
                {(analytics?.emailNotifications || []).length === 0 ? (
                  <p className="py-4 text-slate-500">
                    Notifications sent to citizens with email addresses will appear here.
                  </p>
                ) : (
                  analytics?.emailNotifications.map((em) => (
                    <div key={em.id} className="py-2.5 flex items-center justify-between gap-3">
                      <div>
                        <div className="font-semibold text-slate-900">
                          {em.complaintCode} · {em.recipientEmail}
                        </div>
                        <div className="text-slate-600">{em.subject}</div>
                      </div>
                      <span className="font-mono-tabular text-slate-500 shrink-0">
                        {em.deliveryStatus}
                      </span>
                    </div>
                  ))
                )}
              </div>
            </div>

            <div className="p-6 rounded-xl bg-white border border-slate-200 space-y-3">
              <h2 className="font-display text-lg font-bold text-slate-900">
                Admin Activity Audit Log
              </h2>
              <div className="divide-y divide-slate-100 max-h-[280px] overflow-y-auto text-xs">
                {(analytics?.auditLogs || []).length === 0 ? (
                  <p className="py-4 text-slate-500">No admin actions recorded yet.</p>
                ) : (
                  analytics?.auditLogs.map((log) => (
                    <div key={log.id} className="py-2.5 flex items-start justify-between gap-3">
                      <div>
                        <div className="font-semibold text-slate-900">
                          {log.action} {log.targetCode ? `· ${log.targetCode}` : ''}
                        </div>
                        <div className="text-slate-600">{log.details}</div>
                        <div className="text-slate-400 mt-0.5">{log.actorName}</div>
                      </div>
                      <span className="font-mono-tabular text-slate-400 shrink-0">
                        {new Date(log.createdAt).toLocaleDateString('en-IN')}
                      </span>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SECTION 4: TEAM MANAGEMENT */}
      {section === 'team' && (
        <div className="mt-6 grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <div className="lg:col-span-8 rounded-xl bg-white border border-slate-200 overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-200 bg-slate-50 font-display font-bold text-slate-900">
              Authorized Constituency Team Roster
            </div>
            <div className="divide-y divide-slate-100">
              {teamMembers.map((member) => (
                <div
                  key={member.id}
                  className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                >
                  <div>
                    <div className="font-semibold text-sm text-slate-900">{member.name}</div>
                    <div className="text-xs text-slate-500">
                      {member.email} · {member.assignedArea}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <select
                      disabled={teamProfile?.role !== 'super_admin'}
                      value={member.role}
                      onChange={(e) => handleToggleMember(member, { role: e.target.value })}
                      className="px-2.5 py-1.5 rounded-lg border border-slate-300 text-xs bg-white disabled:opacity-60"
                    >
                      <option value="super_admin">Super Admin</option>
                      <option value="coordinator">Coordinator</option>
                      <option value="field_officer">Field Officer</option>
                      <option value="pending">Pending</option>
                    </select>
                    <button
                      type="button"
                      disabled={teamProfile?.role !== 'super_admin'}
                      onClick={() => handleToggleMember(member, { isActive: !member.isActive })}
                      className={`px-3 py-1.5 rounded-lg text-xs font-semibold border cursor-pointer disabled:opacity-50 ${
                        member.isActive
                          ? 'border-emerald-200 bg-emerald-50 text-emerald-700'
                          : 'border-slate-200 bg-slate-100 text-slate-600'
                      }`}
                    >
                      {member.isActive ? 'Active' : 'Disabled'}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <form
            onSubmit={handleAddTeamMember}
            className="lg:col-span-4 p-6 rounded-xl bg-white border border-slate-200 space-y-4"
          >
            <h2 className="font-display text-lg font-bold text-slate-900">Add Team Member</h2>
            <p className="text-xs text-slate-500">
              Pre-authorize a team member&apos;s Google email to grant Admin Console access.
            </p>
            <input
              type="email"
              required
              value={newMemberEmail}
              onChange={(e) => setNewMemberEmail(e.target.value)}
              placeholder="Officer Google Email *"
              className="w-full min-h-[40px] px-3 rounded-lg border border-slate-300 text-sm"
            />
            <input
              type="text"
              required
              value={newMemberName}
              onChange={(e) => setNewMemberName(e.target.value)}
              placeholder="Full Name *"
              className="w-full min-h-[40px] px-3 rounded-lg border border-slate-300 text-sm"
            />
            <select
              value={newMemberRole}
              onChange={(e) => setNewMemberRole(e.target.value)}
              className="w-full min-h-[40px] px-3 rounded-lg border border-slate-300 text-sm bg-white"
            >
              <option value="field_officer">Field Officer</option>
              <option value="coordinator">Coordinator</option>
              <option value="super_admin">Super Admin</option>
            </select>
            <input
              type="text"
              value={newMemberArea}
              onChange={(e) => setNewMemberArea(e.target.value)}
              placeholder="Assigned Villages / Zone"
              className="w-full min-h-[40px] px-3 rounded-lg border border-slate-300 text-sm"
            />
            <button
              type="submit"
              disabled={addingMember || teamProfile?.role !== 'super_admin'}
              className="w-full min-h-[42px] rounded-lg bg-slate-900 hover:bg-slate-800 disabled:opacity-50 text-white text-xs font-semibold cursor-pointer"
            >
              {teamProfile?.role !== 'super_admin'
                ? 'Super Admin Required'
                : addingMember
                  ? 'Saving...'
                  : 'Authorize Member'}
            </button>
          </form>
        </div>
      )}
    </div>
  );
};
