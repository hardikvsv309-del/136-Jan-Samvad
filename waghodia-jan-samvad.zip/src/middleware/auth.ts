import { Request, Response, NextFunction } from 'express';
import { DecodedIdToken } from 'firebase-admin/auth';
import { adminAuth } from '../lib/firebase-admin.ts';
import { db } from '../db/index.ts';
import { users } from '../db/schema.ts';
import { eq, notLike, sql } from 'drizzle-orm';

export interface TeamUserRecord {
  id: number;
  uid: string;
  email: string;
  name: string;
  role: string;
  assignedArea: string;
  isActive: boolean;
}

export interface AuthRequest extends Request {
  user?: DecodedIdToken;
  teamUser?: TeamUserRecord;
}

const OWNER_EMAIL = 'hardikvsv309@gmail.com';

export async function syncTeamUser(
  uid: string,
  email: string,
  displayName?: string
): Promise<TeamUserRecord> {
  const normalizedEmail = email.trim().toLowerCase();
  const safeName = displayName?.trim() || normalizedEmail.split('@')[0];

  const existingByUid = await db
    .select()
    .from(users)
    .where(eq(users.uid, uid))
    .limit(1);

  if (existingByUid.length > 0) {
    return existingByUid[0];
  }

  const existingByEmail = await db
    .select()
    .from(users)
    .where(eq(users.email, normalizedEmail))
    .limit(1);

  if (existingByEmail.length > 0) {
    const updated = await db
      .update(users)
      .set({
        uid,
        name: existingByEmail[0].name || safeName,
      })
      .where(eq(users.id, existingByEmail[0].id))
      .returning();
    return updated[0];
  }

  const realAdminCountRes = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(users)
    .where(notLike(users.uid, 'seed:%'));
  const realUserCount = realAdminCountRes[0]?.count ?? 0;

  const isOwner = normalizedEmail === OWNER_EMAIL;
  const assignedRole = isOwner || realUserCount === 0 ? 'super_admin' : 'pending';

  const inserted = await db
    .insert(users)
    .values({
      uid,
      email: normalizedEmail,
      name: safeName,
      role: assignedRole,
      assignedArea: 'All Villages',
      isActive: true,
    })
    .onConflictDoUpdate({
      target: users.email,
      set: { uid },
    })
    .returning();

  return inserted[0];
}

export const requireAuth = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Unauthorized: Missing token' });
  }

  const token = authHeader.split('Bearer ')[1];
  try {
    const decodedToken = await adminAuth.verifyIdToken(token);
    req.user = decodedToken;

    const email = decodedToken.email || `${decodedToken.uid}@verified.local`;
    const teamUser = await syncTeamUser(decodedToken.uid, email, decodedToken.name);
    req.teamUser = teamUser;

    next();
  } catch (error) {
    console.error('Error verifying Firebase ID token:', error);
    return res.status(401).json({ error: 'Unauthorized: Invalid or expired token' });
  }
};

export const requireAuthorizedTeam = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
) => {
  await requireAuth(req, res, () => {
    const role = req.teamUser?.role;
    const isActive = req.teamUser?.isActive;
    if (!isActive || !role || role === 'pending') {
      return res.status(403).json({
        error: 'Access pending authorization by constituency super admin.',
        code: 'ROLE_PENDING',
        teamUser: req.teamUser,
      });
    }
    next();
  });
};
