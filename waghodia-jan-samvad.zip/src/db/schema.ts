import { relations } from 'drizzle-orm';
import {
  boolean,
  doublePrecision,
  integer,
  jsonb,
  pgTable,
  serial,
  text,
  timestamp,
} from 'drizzle-orm/pg-core';

export interface MediaAttachment {
  url: string;
  type: 'image' | 'video';
  name: string;
}

export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  uid: text('uid').notNull().unique(),
  email: text('email').notNull().unique(),
  name: text('name').notNull().default('Team Member'),
  role: text('role').notNull().default('pending'), // 'super_admin' | 'coordinator' | 'field_officer' | 'pending'
  assignedArea: text('assigned_area').notNull().default('All Villages'),
  isActive: boolean('is_active').notNull().default(true),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const complaints = pgTable('complaints', {
  id: serial('id').primaryKey(),
  complaintCode: text('complaint_code').notNull().unique(),
  citizenName: text('citizen_name').notNull(),
  mobileNumber: text('mobile_number').notNull(),
  citizenEmail: text('citizen_email'),
  village: text('village').notNull(),
  category: text('category').notNull(),
  title: text('title').notNull(),
  description: text('description').notNull(),
  latitude: doublePrecision('latitude').notNull(),
  longitude: doublePrecision('longitude').notNull(),
  locationLabel: text('location_label').notNull().default(''),
  mediaUrls: jsonb('media_urls').$type<MediaAttachment[]>().notNull().default([]),
  status: text('status').notNull().default('submitted'), // 'submitted' | 'verified' | 'in_progress' | 'resolved'
  priority: text('priority').notNull().default('normal'), // 'normal' | 'high' | 'urgent'
  assignedToId: integer('assigned_to_id').references(() => users.id, { onDelete: 'set null' }),
  assignedToName: text('assigned_to_name'),
  internalNotes: text('internal_notes').notNull().default(''),
  actionTaken: text('action_taken').notNull().default(''),
  resultSummary: text('result_summary').notNull().default(''),
  beforePhotos: jsonb('before_photos').$type<string[]>().notNull().default([]),
  afterPhotos: jsonb('after_photos').$type<string[]>().notNull().default([]),
  isPublicShowcase: boolean('is_public_showcase').notNull().default(false),
  consentAccepted: boolean('consent_accepted').notNull().default(true),
  submissionHash: text('submission_hash'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
  resolvedAt: timestamp('resolved_at'),
});

export const complaintTimeline = pgTable('complaint_timeline', {
  id: serial('id').primaryKey(),
  complaintId: integer('complaint_id')
    .references(() => complaints.id, { onDelete: 'cascade' })
    .notNull(),
  status: text('status').notNull(),
  publicNote: text('public_note').notNull(),
  actorName: text('actor_name').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const publicUpdates = pgTable('public_updates', {
  id: serial('id').primaryKey(),
  titleGu: text('title_gu').notNull(),
  titleHi: text('title_hi').notNull(),
  titleEn: text('title_en').notNull(),
  summaryGu: text('summary_gu').notNull(),
  summaryHi: text('summary_hi').notNull(),
  summaryEn: text('summary_en').notNull(),
  category: text('category').notNull(),
  village: text('village').notNull().default('Waghodia'),
  publishedAt: timestamp('published_at').defaultNow().notNull(),
});

export const auditLogs = pgTable('admin_audit_logs', {
  id: serial('id').primaryKey(),
  actorEmail: text('actor_email').notNull(),
  actorName: text('actor_name').notNull(),
  action: text('action').notNull(),
  targetCode: text('target_code'),
  details: text('details').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const emailNotifications = pgTable('email_notifications', {
  id: serial('id').primaryKey(),
  complaintId: integer('complaint_id').references(() => complaints.id, { onDelete: 'cascade' }),
  complaintCode: text('complaint_code').notNull(),
  recipientEmail: text('recipient_email').notNull(),
  subject: text('subject').notNull(),
  bodyPreview: text('body_preview').notNull(),
  deliveryStatus: text('delivery_status').notNull().default('queued_no_smtp'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const usersRelations = relations(users, ({ many }) => ({
  assignedComplaints: many(complaints),
}));

export const complaintsRelations = relations(complaints, ({ one, many }) => ({
  assignee: one(users, {
    fields: [complaints.assignedToId],
    references: [users.id],
  }),
  timeline: many(complaintTimeline),
  notifications: many(emailNotifications),
}));

export const complaintTimelineRelations = relations(complaintTimeline, ({ one }) => ({
  complaint: one(complaints, {
    fields: [complaintTimeline.complaintId],
    references: [complaints.id],
  }),
}));

export const emailNotificationsRelations = relations(emailNotifications, ({ one }) => ({
  complaint: one(complaints, {
    fields: [emailNotifications.complaintId],
    references: [complaints.id],
  }),
}));
