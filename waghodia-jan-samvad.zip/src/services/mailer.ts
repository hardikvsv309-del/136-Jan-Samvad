import nodemailer from 'nodemailer';
import { db } from '../db/index.ts';
import { emailNotifications } from '../db/schema.ts';

interface DispatchNotificationParams {
  complaintId: number;
  complaintCode: string;
  recipientEmail: string;
  subject: string;
  bodyText: string;
}

export async function dispatchEmailNotification(params: DispatchNotificationParams): Promise<void> {
  const { complaintId, complaintCode, recipientEmail, subject, bodyText } = params;
  const cleanRecipient = recipientEmail.trim();
  if (!cleanRecipient) return;

  let deliveryStatus: 'sent' | 'queued_no_smtp' | 'failed' = 'queued_no_smtp';

  const smtpHost = process.env.SMTP_HOST;
  const smtpUser = process.env.SMTP_USER;
  const smtpPass = process.env.SMTP_PASS;
  const smtpPort = Number(process.env.SMTP_PORT || '587');
  const smtpFrom = process.env.SMTP_FROM || 'no-reply@waghodiajansamvad.org';

  if (smtpHost && smtpUser && smtpPass) {
    try {
      const transporter = nodemailer.createTransport({
        host: smtpHost,
        port: smtpPort,
        secure: smtpPort === 465,
        auth: {
          user: smtpUser,
          pass: smtpPass,
        },
      });

      await transporter.sendMail({
        from: `"Waghodia Jan Samvad" <${smtpFrom}>`,
        to: cleanRecipient,
        subject,
        text: bodyText,
      });
      deliveryStatus = 'sent';
    } catch (error) {
      console.error('SMTP email dispatch failed:', error);
      deliveryStatus = 'failed';
    }
  }

  try {
    await db.insert(emailNotifications).values({
      complaintId,
      complaintCode,
      recipientEmail: cleanRecipient,
      subject,
      bodyPreview: bodyText.slice(0, 400),
      deliveryStatus,
    });
  } catch (error) {
    console.error('Failed to record email notification audit:', error);
  }
}
