import { ProblemCategory } from '../types/index.ts';

export interface VillageInfo {
  id: string;
  nameEn: string;
  nameGu: string;
  nameHi: string;
  lat: number;
  lng: number;
}

export const WAGHODIA_CENTER = { lat: 22.3039, lng: 73.3935 };

const RAW_VILLAGES: Array<[string, string, string, number?, number?]> = [
  ['Abhrampura', 'અભરામપુરા', 'अभरामपुरा'],
  ['Adiran', 'અદિરણ', 'अदिरण'],
  ['Alva', 'અલવા', 'अलवा', 22.2815, 73.4552],
  ['Ambali', 'આંબલી', 'आंबली'],
  ['Amodar', 'અમોદર', 'अमोदर', 22.2921, 73.3348],
  ['Amreshwar', 'અમરેશ્વર', 'अमरेश्वर'],
  ['Amrutpura', 'અમૃતપુરા', 'अमृतपुरा'],
  ['Antoli', 'અંતોલી', 'अंतोली'],
  ['Asha', 'આશા', 'आशा'],
  ['Asoj', 'અસોજ', 'असोज', 22.3694, 73.2683],
  ['Bakrol', 'બાકરોલ', 'बाकरोल', 22.3391, 73.3724],
  ['Bhadol Khurd', 'ભડોલ ખુર્દ', 'भडोल खुर्द'],
  ['Bhaniyara', 'ભણીયારા', 'भणियारा', 22.3315, 73.3182],
  ['Bhaupura', 'ભાઉપુરા', 'भाउपुरा'],
  ['Bodidra', 'બોડીદ્રા', 'बोडीद्रा'],
  ['Chandpur', 'ચાંદપુર', 'चांदपुर'],
  ['Chipad', 'ચીપડ', 'चीपड'],
  ['Chipat', 'ચીપટ', 'चीपट'],
  ['Dankheda', 'દાનખેડા', 'दानखेड़ा'],
  ['Dattapura', 'દત્તાપુરા', 'दत्तापुरा'],
  ['Dharola', 'ધરોલા', 'धरोला'],
  ['Dundelav', 'ડુંડેલાવ', 'डुंडेलाव'],
  ['Falod', 'ફલોદ', 'फलोद'],
  ['Gajadra', 'ગજાદરા', 'गजादरा'],
  ['Gambhirpura', 'ગંભીરપુરા', 'गंभीरपुरा'],
  ['Ganeshpura', 'ગણેશપુરા', 'गणेशपुरा'],
  ['Ghoda', 'ઘોડા', 'घोडा'],
  ['Ghodadra', 'ઘોડાદરા', 'घोड़ादरा'],
  ['Goraj', 'ગોરજ', 'गोरज', 22.2572, 73.4418],
  ['Gugalpur', 'ગુગલપુર', 'गुगलपुर'],
  ['Gutal', 'ગુતાલ', 'गुताल'],
  ['Hamirpuri', 'હમીરપુરી', 'हमीरपुरी'],
  ['Hansapura', 'હંસાપુરા', 'हंसापुरा'],
  ['Hanumanpura', 'હનુમાનપુરા', 'हनुमानपुरा'],
  ['Intoli', 'ઇંટોલી', 'इंटोली'],
  ['Jafarpura', 'જાફરપુરા', 'जाफरपुरा'],
  ['Jambuwada', 'જાંબુવાડા', 'जांबुवाड़ा'],
  ['Jarod', 'જરોદ', 'जरोद', 22.3578, 73.3219],
  ['Jesangpura', 'જેસંગપુરા', 'जेसंगपुरा'],
  ['Juna Rampura', 'જૂના રામપુરા', 'जुना रामपुरा'],
  ['Kachhota', 'કછોટા', 'कछोटा'],
  ['Kamlapura', 'કમલાપુરા', 'कमलापुरा'],
  ['Kamrol', 'કામરોલ', 'कामरोल'],
  ['Karamliya Pura', 'કરમલીયા પુરા', 'करमलिया पुरा'],
  ['Karmasiya Kheda', 'કરમસીયા ખેડા', 'करमसिया खेड़ा'],
  ['Khandha', 'ખંધા', 'खंधा', 22.3164, 73.4384],
  ['Khandiwada', 'ખંડીવાડા', 'खंडीवाड़ा'],
  ['Khervadi', 'ખેરવાડી', 'खेरवाड़ी'],
  ['Koba', 'કોબા', 'कोबा'],
  ['Kodarvaya', 'કોદરવાયા', 'कोदरवाया'],
  ['Kotambi', 'કોટંબી', 'कोटंबी', 22.3482, 73.2974],
  ['Kumetha', 'કુમેઠા', 'कुमेठा', 22.2995, 73.4511],
  ['Lilora', 'લીલોરા', 'लीलोरा'],
  ['Limda', 'લીમડા', 'लीमड़ा', 22.2881, 73.3614],
  ['Madheli', 'મઢેલી', 'मढ़ेली'],
  ['Madodhar', 'મડોધર', 'मडोधर', 22.2752, 73.3321],
  ['Mastupura', 'મસ્તુપુરા', 'मस्तुपुरा'],
  ['Morlipura', 'મોરલીપુરા', 'मोरलीपुरा'],
  ['Moti Manekpur', 'મોટી માણેકપુર', 'मोटी मानेकपुर'],
  ['Nani Manekpur', 'નાની માણેકપુર', 'नानी मानेकपुर'],
  ['Nava Ajva', 'નવા આજવા', 'नवा आजवा', 22.3712, 73.3385],
  ['Nava Rampura', 'નવા રામપુરા', 'नवा रामपुरा'],
  ['Navgam', 'નવગામ', 'नवगाम'],
  ['Navi Jambuvai', 'નવી જાંબુવાઈ', 'नवी जांबुवाई'],
  ['Nimetha', 'નિમેઠા', 'निमेठा', 22.3112, 73.3105],
  ['Nurpuri', 'નૂરપુરી', 'नूरपुरी'],
  ['Paldi', 'પાલડી', 'पालडी'],
  ['Panch Devla', 'પાંચ દેવલા', 'पांच देवला'],
  ['Pavlepur', 'પાવલેપુર', 'पावलेपुर', 22.3455, 73.4461],
  ['Pipaliya', 'પીપળીયા', 'पिपलिया', 22.2974, 73.4126],
  ['Rahkui', 'રાહકુઈ', 'राहकुई'],
  ['Rajpura', 'રાજપુરા', 'राजपुरा'],
  ['Rasulabad', 'રસૂલાબાદ', 'रसूलाबाद', 22.2644, 73.4192],
  ['Raval', 'રાવળ', 'रावल', 22.3198, 73.3478],
  ['Rayan Talavadi', 'રાયણ તલાવડી', 'रायण तलावडी'],
  ['Ropa', 'રોપા', 'रोपा'],
  ['Rustampura', 'રુસ્તમપુરા', 'रुस्तमपुरा', 22.2485, 73.3742],
  ['Saidal', 'સૈદલ', 'सैदल'],
  ['Sakariya', 'સાકરીયા', 'साकरिया'],
  ['Sangadol', 'સંગાડોલ', 'संगाडोल'],
  ['Sanoli', 'સનોલી', 'सनोली'],
  ['Sarnej', 'સરનેજ', 'सरनेज'],
  ['Shripore Timbi', 'શ્રીપોર ટીંબી', 'श्रीपोर टींबी'],
  ['Sikandarpura', 'સિકંદરપુરા', 'सिकंदरपुरा'],
  ['Tarsva', 'તરસવા', 'तरसवा'],
  ['Tavra', 'તાવરા', 'तावरा', 22.2651, 73.3562],
  ['Timbi', 'ટીંબી', 'टींबी'],
  ['Umarva', 'ઉમરવા', 'उमरवा'],
  ['Vaghodia', 'વાઘોડિયા', 'वाघोडिया', 22.3039, 73.3935],
  ['Valva', 'વાલવા', 'वालवा'],
  ['Vasvel', 'વાસવેલ', 'वासवेल'],
  ['Vedpur', 'વેદપુર', 'वेदपुर'],
  ['Vejalpur', 'વેજલપુર', 'वेजलपुर'],
  ['Vesaniya', 'વેસાણીયા', 'वेसानिया', 22.3324, 73.4018],
  ['Vyankatpura', 'વ્યંકટપુરા', 'व्यंकटपुरा'],
  ['Vyara', 'વ્યારા', 'व्यारा', 22.3256, 73.4281],
];

function computeTalukaCoords(index: number): { lat: number; lng: number } {
  // Deterministic spiral distribution within ~8km Waghodia taluka radius
  const angle = index * 2.39996;
  const radius = 0.015 + ((index % 12) / 12) * 0.06;
  return {
    lat: Number((WAGHODIA_CENTER.lat + Math.sin(angle) * radius).toFixed(4)),
    lng: Number((WAGHODIA_CENTER.lng + Math.cos(angle) * radius).toFixed(4)),
  };
}

export const WAGHODIA_VILLAGES: VillageInfo[] = RAW_VILLAGES.map(
  ([nameEn, nameGu, nameHi, lat, lng], idx) => {
    const fallback = computeTalukaCoords(idx + 1);
    return {
      id: nameEn,
      nameEn,
      nameGu,
      nameHi,
      lat: lat ?? fallback.lat,
      lng: lng ?? fallback.lng,
    };
  }
);

export const PROBLEM_CATEGORIES: ProblemCategory[] = [
  'roads',
  'drainage',
  'drinking_water',
  'electricity',
  'education',
  'healthcare',
  'transport',
  'agriculture',
  'employment',
  'govt_services',
  'other',
];

export const HERO_IMAGE = '/src/assets/images/hero_waghodia_civic_1795184508487.jpg';
export const VISION_IMAGE = '/src/assets/images/vision_waghodia_school_1795184508939.jpg';
