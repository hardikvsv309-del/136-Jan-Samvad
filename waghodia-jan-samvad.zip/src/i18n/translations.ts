import { ComplaintStatus, Language, ProblemCategory } from '../types/index.ts';

export const CATEGORY_LABELS: Record<Language, Record<ProblemCategory, string>> = {
  gu: {
    roads: 'રસ્તા અને પુલ',
    drainage: 'ગટર અને વરસાદી નિકાલ',
    drinking_water: 'પીવાનું પાણી',
    electricity: 'વીજળી અને સ્ટ્રીટ લાઇટ',
    education: 'શિક્ષણ અને શાળા',
    healthcare: 'આરોગ્ય અને દવાખાના',
    transport: 'પરિવહન અને એસ.ટી. બસ',
    agriculture: 'ખેતી અને સિંચાઈ',
    employment: 'રોજગાર અને કૌશલ્ય',
    govt_services: 'સરકારી સેવાઓ / દસ્તાવેજ',
    other: 'અન્ય સમસ્યા',
  },
  hi: {
    roads: 'सड़कें और पुल',
    drainage: 'जल निकासी और नाली',
    drinking_water: 'पेयजल आपूर्ति',
    electricity: 'बिजली और स्ट्रीट लाइट',
    education: 'शिक्षा और विद्यालय',
    healthcare: 'स्वास्थ्य और अस्पताल',
    transport: 'परिवहन और बस सेवा',
    agriculture: 'कृषि और सिंचाई',
    employment: 'रोजगार और कौशल',
    govt_services: 'सरकारी सेवाएं',
    other: 'अन्य समस्या',
  },
  en: {
    roads: 'Roads',
    drainage: 'Drainage',
    drinking_water: 'Drinking Water',
    electricity: 'Electricity',
    education: 'Education',
    healthcare: 'Healthcare',
    transport: 'Transport',
    agriculture: 'Agriculture',
    employment: 'Employment',
    govt_services: 'Government Services',
    other: 'Other',
  },
};

export const STATUS_LABELS: Record<Language, Record<ComplaintStatus, string>> = {
  gu: {
    submitted: 'નોંધાયેલ',
    verified: 'ચકાસાયેલ',
    in_progress: 'કાર્યવાહી હેઠળ',
    resolved: 'ઉકેલાયેલ',
  },
  hi: {
    submitted: 'दर्ज की गई',
    verified: 'सत्यापित',
    in_progress: 'कार्रवाई जारी',
    resolved: 'समाधान पूर्ण',
  },
  en: {
    submitted: 'Submitted',
    verified: 'Verified',
    in_progress: 'Follow-up / Action Taken',
    resolved: 'Resolved',
  },
};

export interface Translations {
  brandTitle: string;
  navHome: string;
  navTrack: string;
  navIssues: string;
  navWork: string;
  navVision: string;
  navAdmin: string;
  navReportCta: string;
  heroEyebrow: string;
  heroTitle: string;
  heroSubtitle: string;
  heroPrimaryCta: string;
  heroSecondaryCta: string;
  quickTrackPlaceholder: string;
  quickTrackBtn: string;
  statTotal: string;
  statResolved: string;
  statFollowUp: string;
  statPending: string;
  updatesHeading: string;
  updatesSub: string;
  aboutHeading: string;
  aboutBody: string;
  aboutPoint1Title: string;
  aboutPoint1Body: string;
  aboutPoint2Title: string;
  aboutPoint2Body: string;
  aboutPoint3Title: string;
  aboutPoint3Body: string;
  contactHeading: string;
  contactOffice: string;
  contactHours: string;
  contactHelpline: string;
  contactEmail: string;
  reportTitle: string;
  reportSubtitle: string;
  fieldName: string;
  fieldNamePh: string;
  fieldMobile: string;
  fieldMobilePh: string;
  fieldEmail: string;
  fieldEmailPh: string;
  fieldVillage: string;
  fieldCategory: string;
  fieldSubject: string;
  fieldSubjectPh: string;
  fieldDescription: string;
  fieldDescriptionPh: string;
  fieldMedia: string;
  fieldMediaHint: string;
  fieldLocation: string;
  useGpsBtn: string;
  gpsLocating: string;
  gpsTip: string;
  privacyConsent: string;
  submitComplaintBtn: string;
  submittingBtn: string;
  submittedSuccessTitle: string;
  submittedSuccessMsg: string;
  yourComplaintId: string;
  copyIdBtn: string;
  copiedMsg: string;
  trackNowBtn: string;
  submitAnotherBtn: string;
  trackHeading: string;
  trackSub: string;
  trackSearchBtn: string;
  trackSampleLabel: string;
  trackLiveLabel: string;
  trackNotFound: string;
  trackTimelineTitle: string;
  trackActionLabel: string;
  trackResultLabel: string;
  issuesHeading: string;
  issuesSub: string;
  issuesPrivacyNote: string;
  filterAllVillages: string;
  filterAllCategories: string;
  filterAllStatuses: string;
  workHeading: string;
  workSub: string;
  workProblemLabel: string;
  workActionLabel: string;
  workResultLabel: string;
  workBeforeLabel: string;
  workAfterLabel: string;
  visionHeading: string;
  visionSub: string;
  visionIntro: string;
  footerPrivacyNote: string;
}

export const TRANSLATIONS: Record<Language, Translations> = {
  gu: {
    brandTitle: 'વાઘોડિયા જન સંવાદ',
    navHome: 'મુખ્ય પૃષ્ઠ',
    navTrack: 'સ્થિતિ તપાસો',
    navIssues: 'જાહેર પ્રશ્નો',
    navWork: 'અમારું કાર્ય',
    navVision: 'વિઝન ૨૦૩૦',
    navAdmin: 'એડમિન',
    navReportCta: 'સમસ્યા નોંધાવો',
    heroEyebrow: 'વાઘોડિયા વિધાનસભા · નાગરિક ફરિયાદ અને વિકાસ પોર્ટલ',
    heroTitle: 'તમારા ગામ કે વિસ્તારની સમસ્યા સીધી અહીં નોંધાવો',
    heroSubtitle:
      'રસ્તા, પાણી, ગટર, વીજળી, શિક્ષણ કે આરોગ્ય જેવી જાહેર સમસ્યાઓ ફોટો અને લોકેશન સાથે ઓનલાઈન મોકલો અને તમારા ફરિયાદ નંબરથી લાઈવ સ્થિતિ જાણો.',
    heroPrimaryCta: 'તમારી સમસ્યા નોંધાવો',
    heroSecondaryCta: 'અમારું કાર્ય જુઓ',
    quickTrackPlaceholder: 'ફરિયાદ નંબર દાખલ કરો (દા.ત. WJS-2026-0101)',
    quickTrackBtn: 'સ્થિતિ જુઓ',
    statTotal: 'કુલ ફરિયાદો',
    statResolved: 'ઉકેલાયેલ કાર્યો',
    statFollowUp: 'કાર્યવાહી હેઠળ',
    statPending: 'પ્રાથમિક ચકાસણીમાં',
    updatesHeading: 'તાજેતરની જાહેરાતો અને વિકાસ અપડેટ્સ',
    updatesSub: 'વાઘોડિયા તાલુકાના વિવિધ ગામોમાં ચાલી રહેલા અને પૂર્ણ થયેલા લોકહિતના કાર્યો.',
    aboutHeading: 'વાઘોડિયા જન સંવાદ વિશે',
    aboutBody:
      'વાઘોડિયા જન સંવાદ એ નાગરિકો અને જનપ્રતિનિધિ કાર્યાલય વચ્ચે પારદર્શક, જવાબદાર અને ઝડપી સંવાદનો સેતુ છે. દરેક ફરિયાદની નોંધણીથી લઈને સ્થળ તપાસ અને અંતિમ નિરાકરણ સુધીની વિગત ડિજિટલ રેકોર્ડ પર ઉપલબ્ધ રહે છે.',
    aboutPoint1Title: '૧૦૦% ગોપનીયતા સુરક્ષા',
    aboutPoint1Body:
      'નાગરિકના મોબાઇલ નંબર, નામ કે ઘરનું ચોક્કસ સરનામું જાહેર નકશા કે ટ્રેકિંગ પર ક્યારેય દર્શાવવામાં આવતું નથી.',
    aboutPoint2Title: 'રીઅલ-ટાઇમ પ્રગતિ ટ્રેકિંગ',
    aboutPoint2Body:
      'ફરિયાદ નોંધાવતા જ તમને યુનિક ID મળે છે જેનાથી નોંધણી → ચકાસણી → કાર્યવાહી → ઉકેલના દરેક તબક્કાની જીવંત માહિતી મળે છે.',
    aboutPoint3Title: 'પહેલાં અને પછીના પુરાવા',
    aboutPoint3Body:
      'દરેક પૂર્ણ થયેલ કામની વિગત સમસ્યા, લેવાયેલ પગલાં અને સ્થળ પરના ફોટોગ્રાફ્સ સાથે પારદર્શક રીતે પ્રદર્શિત થાય છે.',
    contactHeading: 'જનસંપર્ક કાર્યાલય અને સહાય',
    contactOffice: 'વાઘોડિયા જન સંવાદ સેવા કેન્દ્ર, સ્ટેશન રોડ, વાઘોડિયા - ૩૯૧૭૬૦',
    contactHours: 'સોમવાર થી શનિવાર · સવારે ૯:૩૦ થી સાંજે ૬:૦૦',
    contactHelpline: '૦૨૬૬૮-૨૬૨૧૦૦ (કાર્યાલય સહાય)',
    contactEmail: 'samvad@waghodiajansamvad.org',
    reportTitle: 'નવી જાહેર સમસ્યા નોંધાવો',
    reportSubtitle: 'સરળ ફોર્મ ભરો — કોઈ તકનીકી જ્ઞાનની જરૂર નથી. માત્ર ૨ મિનિટમાં ફરિયાદ નોંધાશે.',
    fieldName: 'તમારું પૂરું નામ *',
    fieldNamePh: 'દા.ત. રમેશભાઈ પરમાર',
    fieldMobile: 'મોબાઇલ નંબર (૧૦ અંક) *',
    fieldMobilePh: '૯૮XXXXXXXX',
    fieldEmail: 'ઈમેલ સરનામું (વૈકલ્પિક - ઓટોમેટિક અપડેટ માટે)',
    fieldEmailPh: 'name@example.com',
    fieldVillage: 'ગામ / વિસ્તાર પસંદ કરો *',
    fieldCategory: 'સમસ્યાનો પ્રકાર *',
    fieldSubject: 'સમસ્યાનું ટૂંકું શીર્ષક',
    fieldSubjectPh: 'દા.ત. પ્રાથમિક શાળા પાસે રસ્તા પર ખાડા',
    fieldDescription: 'સમસ્યાની વિગતવાર માહિતી *',
    fieldDescriptionPh: 'ક્યાં અને શું સમસ્યા છે તેની સરળ વિગત લખો...',
    fieldMedia: 'ફોટો અથવા વિડિયો અપલોડ કરો (મહત્તમ ૪ ફાઇલ)',
    fieldMediaHint: 'JPG, PNG, WEBP ફોટો અથવા MP4 વિડિયો (૧૫ MB સુધી)',
    fieldLocation: 'નકશા પર સ્થળ પસંદ કરો અથવા પિન ખસેડો',
    useGpsBtn: 'મારું હાલનું GPS લોકેશન લો',
    gpsLocating: 'લોકેશન શોધાઈ રહ્યું છે...',
    gpsTip: 'તમે નકશા પર સીધું ક્લિક કરીને પણ સમસ્યાનું સ્થળ પસંદ કરી શકો છો.',
    privacyConsent:
      'હું સંમત છું કે મારી ફરિયાદના નિરાકરણ માટે વાઘોડિયા જન સંવાદ ટીમ મારો સંપર્ક કરી શકે છે. મારો ફોન નંબર અને અંગત વિગતો જાહેર જનતા સમક્ષ મૂકવામાં આવશે નહીં.',
    submitComplaintBtn: 'ફરિયાદ સબમિટ કરો',
    submittingBtn: 'નોંધણી થઈ રહી છે...',
    submittedSuccessTitle: 'તમારી ફરિયાદ સફળતાપૂર્વક નોંધાઈ ગઈ છે',
    submittedSuccessMsg:
      'ભવિષ્યમાં સ્થિતિ તપાસવા માટે નીચે આપેલ ફરિયાદ નંબર સાચવી રાખો.',
    yourComplaintId: 'તમારો ફરિયાદ નંબર (Complaint ID)',
    copyIdBtn: 'નંબર કોપી કરો',
    copiedMsg: 'કોપી થયું!',
    trackNowBtn: 'આ ફરિયાદ ટ્રેક કરો',
    submitAnotherBtn: 'બીજી સમસ્યા નોંધાવો',
    trackHeading: 'ફરિયાદની સ્થિતિ ટ્રેક કરો',
    trackSub: 'તમારો યુનિક Complaint ID દાખલ કરી લાઈવ પ્રગતિ અને અધિકારીની નોંધ જુઓ.',
    trackSearchBtn: 'સ્થિતિ શોધો',
    trackSampleLabel: 'ઉદાહરણ ID:',
    trackLiveLabel: 'લાઈવ અપડેટ્સ સક્રિય',
    trackNotFound: 'આ નંબર સાથે કોઈ ફરિયાદ મળી નથી. કૃપા કરીને નંબર ચકાસો.',
    trackTimelineTitle: 'કાર્યવાહીનો સમયક્રમ',
    trackActionLabel: 'લેવાયેલા પગલાં',
    trackResultLabel: 'અંતિમ પરિણામ',
    issuesHeading: 'જાહેર પ્રશ્નો અને વિસ્તાર નકશો',
    issuesSub: 'વાઘોડિયા તાલુકામાં નોંધાયેલી સમસ્યાઓની આંકડાકીય વિગત અને અંદાજિત વિસ્તાર નકશો.',
    issuesPrivacyNote:
      'નાગરિકની ગોપનીયતા માટે જાહેર નકશા પર માત્ર ગામ/વિસ્તારનું અંદાજિત લોકેશન દર્શાવાય છે — ફોન નંબર કે નામ જાહેર કરાતા નથી.',
    filterAllVillages: 'બધા ગામો',
    filterAllCategories: 'બધી કેટેગરી',
    filterAllStatuses: 'બધી સ્થિતિ',
    workHeading: 'અમારું કાર્ય — પારદર્શક પ્રગતિ',
    workSub: 'નાગરિકોની રજૂઆત બાદ પૂર્ણ થયેલા કાર્યોના પહેલાં અને પછીના ફોટોગ્રાફ્સ સાથેનો અહેવાલ.',
    workProblemLabel: 'સમસ્યા',
    workActionLabel: 'લેવાયેલ પગલાં',
    workResultLabel: 'પરિણામ',
    workBeforeLabel: 'પહેલાં',
    workAfterLabel: 'પછી',
    visionHeading: 'વાઘોડિયા વિઝન ૨૦૩૦',
    visionSub: 'વિકસિત, આત્મનિર્ભર અને સમૃદ્ધ વાઘોડિયાના નિર્માણ માટેના ૮ મુખ્ય સ્તંભો.',
    visionIntro:
      'ગામેગામ પાયાની સુવિધાઓથી લઈને યુવાનો માટે સ્થાનિક રોજગારી અને આધુનિક ખેતી સુધી, ૨૦૩૦ સુધીનો સ્પષ્ટ વિકાસ રોડમેપ.',
    footerPrivacyNote: 'નાગરિક ગોપનીયતા સુરક્ષિત · વાઘોડિયા વિધાનસભા જાહેર સેવા પ્લેટફોર્મ',
  },
  hi: {
    brandTitle: 'वाघोडिया जन संवाद',
    navHome: 'मुख्य पृष्ठ',
    navTrack: 'स्थिति देखें',
    navIssues: 'सार्वजनिक मुद्दे',
    navWork: 'हमारा कार्य',
    navVision: 'विज़न 2030',
    navAdmin: 'एडमिन',
    navReportCta: 'समस्या दर्ज करें',
    heroEyebrow: 'वाघोडिया विधानसभा · नागरिक शिकायत और विकास पोर्टल',
    heroTitle: 'अपने गांव या क्षेत्र की समस्या सीधे यहां दर्ज करें',
    heroSubtitle:
      'सड़क, पानी, जल निकासी, बिजली, शिक्षा या स्वास्थ्य से जुड़ी सार्वजनिक समस्याएं फोटो और लोकेशन के साथ भेजें और अपनी शिकायत आईडी से लाइव स्थिति ट्रैक करें।',
    heroPrimaryCta: 'अपनी समस्या दर्ज करें',
    heroSecondaryCta: 'हमारा कार्य देखें',
    quickTrackPlaceholder: 'शिकायत आईडी दर्ज करें (जैसे WJS-2026-0101)',
    quickTrackBtn: 'स्थिति जांचें',
    statTotal: 'कुल शिकायतें',
    statResolved: 'समाधान पूर्ण',
    statFollowUp: 'कार्रवाई जारी',
    statPending: 'समीक्षाधीन',
    updatesHeading: 'नवीनतम अपडेट और घोषणाएं',
    updatesSub: 'वाघोडिया क्षेत्र के गांवों में चल रहे और पूर्ण हुए जनहित कार्य।',
    aboutHeading: 'वाघोडिया जन संवाद के बारे में',
    aboutBody:
      'वाघोडिया जन संवाद नागरिकों और जनप्रतिनिधि कार्यालय के बीच पारदर्शी, जवाबदेह और त्वरित संवाद का माध्यम है। शिकायत पंजीकरण से लेकर स्थल निरीक्षण और अंतिम समाधान तक हर चरण डिजिटल रूप से ट्रैक किया जाता है।',
    aboutPoint1Title: '100% गोपनीयता सुरक्षा',
    aboutPoint1Body:
      'नागरिक का मोबाइल नंबर, नाम या सटीक घर का पता सार्वजनिक मानचित्र या ट्रैकिंग पृष्ठ पर कभी प्रदर्शित नहीं किया जाता।',
    aboutPoint2Title: 'रियल-टाइम प्रगति ट्रैकिंग',
    aboutPoint2Body:
      'शिकायत दर्ज करते ही एक यूनिक आईडी मिलती है जिससे दर्ज → सत्यापित → कार्रवाई → समाधान का लाइव स्टेटस देखा जा सकता है।',
    aboutPoint3Title: 'पहले और बाद के प्रमाण',
    aboutPoint3Body:
      'प्रत्येक पूर्ण कार्य का विवरण समस्या, की गई कार्रवाई और पहले/बाद की तस्वीरों के साथ पारदर्शी रूप से दिखाया जाता है।',
    contactHeading: 'जनसंपर्क कार्यालय और सहायता',
    contactOffice: 'वाघोडिया जन संवाद सेवा केंद्र, स्टेशन रोड, वाघोडिया - 391760',
    contactHours: 'सोमवार से शनिवार · सुबह 9:30 से शाम 6:00 बजे तक',
    contactHelpline: '02668-262100 (कार्यालय हेल्पलाइन)',
    contactEmail: 'samvad@waghodiajansamvad.org',
    reportTitle: 'नई सार्वजनिक समस्या दर्ज करें',
    reportSubtitle: 'सरल फॉर्म भरें — किसी तकनीकी ज्ञान की आवश्यकता नहीं। केवल 2 मिनट में शिकायत दर्ज करें।',
    fieldName: 'आपका पूरा नाम *',
    fieldNamePh: 'उदा. रमेशभाई परमार',
    fieldMobile: 'मोबाइल नंबर (10 अंक) *',
    fieldMobilePh: '98XXXXXXXX',
    fieldEmail: 'ईमेल पता (वैकल्पिक - ऑटोमेटिक अपडेट के लिए)',
    fieldEmailPh: 'name@example.com',
    fieldVillage: 'गांव / क्षेत्र चुनें *',
    fieldCategory: 'समस्या की श्रेणी *',
    fieldSubject: 'समस्या का संक्षिप्त शीर्षक',
    fieldSubjectPh: 'उदा. प्राथमिक विद्यालय के पास सड़क पर गड्ढे',
    fieldDescription: 'समस्या का विस्तृत विवरण *',
    fieldDescriptionPh: 'समस्या कहाँ और क्या है, स्पष्ट रूप से लिखें...',
    fieldMedia: 'फोटो या वीडियो अपलोड करें (अधिकतम 4 फाइलें)',
    fieldMediaHint: 'JPG, PNG, WEBP फोटो या MP4 वीडियो (15 MB तक)',
    fieldLocation: 'मानचित्र पर स्थान चुनें या पिन सेट करें',
    useGpsBtn: 'मेरा वर्तमान GPS स्थान लें',
    gpsLocating: 'स्थान खोजा जा रहा है...',
    gpsTip: 'आप मानचित्र पर सीधे क्लिक करके भी समस्या का स्थान चुन सकते हैं।',
    privacyConsent:
      'मैं सहमत हूं कि मेरी शिकायत के समाधान हेतु वाघोडिया जन संवाद टीम मुझसे संपर्क कर सकती है। मेरा फोन नंबर और निजी जानकारी सार्वजनिक नहीं की जाएगी।',
    submitComplaintBtn: 'शिकायत सबमिट करें',
    submittingBtn: 'दर्ज हो रहा है...',
    submittedSuccessTitle: 'आपकी शिकायत सफलतापूर्वक दर्ज हो गई है',
    submittedSuccessMsg: 'भविष्य में स्थिति ट्रैक करने के लिए नीचे दी गई शिकायत आईडी सुरक्षित रखें।',
    yourComplaintId: 'आपकी शिकायत आईडी (Complaint ID)',
    copyIdBtn: 'आईडी कॉपी करें',
    copiedMsg: 'कॉपी हो गया!',
    trackNowBtn: 'अभी ट्रैक करें',
    submitAnotherBtn: 'अन्य समस्या दर्ज करें',
    trackHeading: 'शिकायत की स्थिति ट्रैक करें',
    trackSub: 'अपनी यूनिक शिकायत आईडी दर्ज करें और लाइव प्रगति व कार्रवाई विवरण देखें।',
    trackSearchBtn: 'स्थिति खोजें',
    trackSampleLabel: 'उदाहरण आईडी:',
    trackLiveLabel: 'लाइव अपडेट सक्रिय',
    trackNotFound: 'इस आईडी से कोई शिकायत नहीं मिली। कृपया आईडी जांचें।',
    trackTimelineTitle: 'कार्रवाई की समयरेखा',
    trackActionLabel: 'की गई कार्रवाई',
    trackResultLabel: 'अंतिम परिणाम',
    issuesHeading: 'सार्वजनिक मुद्दे और क्षेत्र मानचित्र',
    issuesSub: 'वाघोडिया क्षेत्र में दर्ज समस्याओं के आंकड़े और अनुमानित क्षेत्र मानचित्र।',
    issuesPrivacyNote:
      'नागरिक गोपनीयता के लिए मानचित्र पर केवल गांव/क्षेत्र का अनुमानित स्थान दिखाया जाता है — फोन नंबर या निजी विवरण सार्वजनिक नहीं होते।',
    filterAllVillages: 'सभी गांव',
    filterAllCategories: 'सभी श्रेणियां',
    filterAllStatuses: 'सभी स्थितियां',
    workHeading: 'हमारा कार्य — पारदर्शी प्रगति',
    workSub: 'नागरिकों की शिकायतों के बाद पूर्ण हुए कार्यों की पहले और बाद की तस्वीरों सहित रिपोर्ट।',
    workProblemLabel: 'समस्या',
    workActionLabel: 'की गई कार्रवाई',
    workResultLabel: 'परिणाम',
    workBeforeLabel: 'पहले',
    workAfterLabel: 'बाद में',
    visionHeading: 'वाघोडिया विज़न 2030',
    visionSub: 'विकसित, आत्मनिर्भर और समृद्ध वाघोडिया के निर्माण के 8 प्रमुख स्तंभ।',
    visionIntro:
      'गांव-गांव बुनियादी सुविधाओं से लेकर स्थानीय युवा रोजगार और आधुनिक कृषि तक, 2030 तक का स्पष्ट विकास रोडमैप।',
    footerPrivacyNote: 'नागरिक गोपनीयता सुरक्षित · वाघोडिया विधानसभा जन सेवा पोर्टल',
  },
  en: {
    brandTitle: 'Waghodia Jan Samvad',
    navHome: 'Home',
    navTrack: 'Track',
    navIssues: 'Public Issues',
    navWork: 'Our Work',
    navVision: 'Vision 2030',
    navAdmin: 'Admin',
    navReportCta: 'Report Problem',
    heroEyebrow: 'Waghodia Constituency · Citizen Grievance & Transparency Portal',
    heroTitle: 'Report local public issues directly and track real progress',
    heroSubtitle:
      'Submit road, drinking water, drainage, electricity, school, or healthcare grievances with photos and location pin. Track every stage transparently with your unique Complaint ID.',
    heroPrimaryCta: 'Report Your Problem',
    heroSecondaryCta: 'Explore Our Work',
    quickTrackPlaceholder: 'Enter Complaint ID (e.g. WJS-2026-0101)',
    quickTrackBtn: 'Track Status',
    statTotal: 'Total Complaints',
    statResolved: 'Resolved Works',
    statFollowUp: 'Under Follow-up',
    statPending: 'Pending Review',
    updatesHeading: 'Latest Constituency Updates',
    updatesSub: 'Verified public works, field camps, and infrastructure milestones across Waghodia.',
    aboutHeading: 'About Waghodia Jan Samvad',
    aboutBody:
      'Waghodia Jan Samvad connects citizens directly with the constituency grievance redressal team. From initial registration and field verification to department follow-up and final resolution, every public grievance is recorded with full accountability.',
    aboutPoint1Title: 'Strict Citizen Privacy',
    aboutPoint1Body:
      'Citizen names, phone numbers, emails, and exact residential coordinates are strictly protected and never exposed on public maps or tracking pages.',
    aboutPoint2Title: 'Real-Time Status Tracking',
    aboutPoint2Body:
      'Receive an instant Complaint ID upon submission and watch live updates across Submitted → Verified → Follow-up → Resolved.',
    aboutPoint3Title: 'Before & After Proof',
    aboutPoint3Body:
      'Completed works are published openly with problem context, action taken, measurable outcome, and site photographs.',
    contactHeading: 'Constituency Office & Citizen Helpdesk',
    contactOffice: 'Waghodia Jan Samvad Seva Kendra, Station Road, Waghodia - 391760',
    contactHours: 'Monday to Saturday · 9:30 AM to 6:00 PM',
    contactHelpline: '02668-262100 (Office Helpline)',
    contactEmail: 'samvad@waghodiajansamvad.org',
    reportTitle: 'Report a Public Problem',
    reportSubtitle: 'Simple mobile-friendly form — takes less than 2 minutes to submit.',
    fieldName: 'Your Full Name *',
    fieldNamePh: 'e.g. Rameshbhai Parmar',
    fieldMobile: 'Mobile Number (10 digits) *',
    fieldMobilePh: '98XXXXXXXX',
    fieldEmail: 'Email Address (Optional — for automated status updates)',
    fieldEmailPh: 'name@example.com',
    fieldVillage: 'Select Village / Area *',
    fieldCategory: 'Problem Category *',
    fieldSubject: 'Short Issue Title',
    fieldSubjectPh: 'e.g. Damaged approach road near primary school',
    fieldDescription: 'Describe the Problem *',
    fieldDescriptionPh: 'Share clear details about the issue and nearby landmark...',
    fieldMedia: 'Upload Photos or Videos (max 4 files)',
    fieldMediaHint: 'JPG, PNG, WEBP photos or MP4, WEBM videos (up to 15 MB each)',
    fieldLocation: 'Pin Problem Location on Map',
    useGpsBtn: 'Use My Current GPS Location',
    gpsLocating: 'Detecting GPS location...',
    gpsTip: 'Tap anywhere on the map to adjust the pin to the exact issue spot.',
    privacyConsent:
      'I consent to the Waghodia Jan Samvad team contacting me to verify and resolve this grievance. My personal phone number and private details will not be displayed publicly.',
    submitComplaintBtn: 'Submit Complaint',
    submittingBtn: 'Submitting...',
    submittedSuccessTitle: 'Complaint Registered Successfully',
    submittedSuccessMsg: 'Save your unique Complaint ID below to track live updates anytime.',
    yourComplaintId: 'Your Unique Complaint ID',
    copyIdBtn: 'Copy ID',
    copiedMsg: 'Copied!',
    trackNowBtn: 'Track This Complaint',
    submitAnotherBtn: 'Report Another Issue',
    trackHeading: 'Track Complaint Status',
    trackSub: 'Enter your Complaint ID to view real-time progress and official action logs.',
    trackSearchBtn: 'Check Status',
    trackSampleLabel: 'Sample IDs:',
    trackLiveLabel: 'Live updates connected',
    trackNotFound: 'No complaint found with that ID. Please check the number and try again.',
    trackTimelineTitle: 'Resolution Timeline',
    trackActionLabel: 'Action Taken',
    trackResultLabel: 'Outcome / Result',
    issuesHeading: 'Public Issue Dashboard & Map',
    issuesSub: 'Real-time constituency grievance statistics and privacy-protected village issue map.',
    issuesPrivacyNote:
      'To protect citizen privacy, public pins display approximate village-area locations only — personal names, phone numbers, and exact addresses are never shown.',
    filterAllVillages: 'All Villages',
    filterAllCategories: 'All Categories',
    filterAllStatuses: 'All Statuses',
    workHeading: 'Our Work — Transparent Delivery',
    workSub: 'Resolved citizen grievances documented with Problem → Action Taken → Result → Before/After Photos.',
    workProblemLabel: 'Problem',
    workActionLabel: 'Action Taken',
    workResultLabel: 'Result',
    workBeforeLabel: 'Before',
    workAfterLabel: 'After',
    visionHeading: 'Waghodia Vision 2030',
    visionSub: 'Eight core development pillars for a resilient, connected, and prosperous Waghodia.',
    visionIntro:
      'From all-weather rural roads and clean household water to smart schools, rural healthcare, and GIDC youth employment—our structured 2030 roadmap.',
    footerPrivacyNote: 'Citizen Privacy Protected · Waghodia Constituency Public Service Platform',
  },
};

export interface VisionPillar {
  id: string;
  num: string;
  title: Record<Language, string>;
  summary: Record<Language, string>;
  target: Record<Language, string>;
}

export const VISION_PILLARS: VisionPillar[] = [
  {
    id: 'infrastructure',
    num: '01',
    title: {
      gu: 'આધુનિક માળખાકીય સુવિધાઓ',
      hi: 'आधुनिक बुनियादी ढांचा',
      en: 'Infrastructure',
    },
    summary: {
      gu: 'દરેક ગ્રામ પંચાયતમાં આધુનિક જનસેવા કેન્દ્રો, સોલર સ્ટ્રીટ લાઇટ અને ડિજિટલ કનેક્ટિવિટી.',
      hi: 'प्रत्येक ग्राम पंचायत में आधुनिक जनसेवा केंद्र, सोलर स्ट्रीट लाइट और डिजिटल कनेक्टिविटी।',
      en: 'Modern panchayat citizen centers, solar street lighting, and reliable fiber connectivity across every gram panchayat.',
    },
    target: {
      gu: '૧૦૦% ગ્રામ્ય ડિજિટલ સેવા કેન્દ્રો',
      hi: '100% ग्रामीण डिजिटल सेवा केंद्र',
      en: '100% Village Civic Centers Upgraded',
    },
  },
  {
    id: 'roads',
    num: '02',
    title: {
      gu: 'રસ્તા અને ગટર વ્યવસ્થા',
      hi: 'सड़कें और जल निकासी',
      en: 'Roads & Drainage',
    },
    summary: {
      gu: 'બારેમાસ ચાલે તેવા મજબૂત એપ્રોચ રોડ, આંતરિક સીસી રોડ અને વરસાદી પાણીના નિકાલની પાકી ગટરો.',
      hi: 'बारहमासी मजबूत एप्रोच रोड, आंतरिक सीसी सड़कें और वर्षा जल निकासी नालियां।',
      en: 'All-weather village approach roads, internal concrete lanes, and engineered stormwater drainage channels.',
    },
    target: {
      gu: '૨૫૦+ કિમી ગ્રામ્ય રોડ અને ડ્રેનેજ',
      hi: '250+ किमी ग्रामीण सड़क और नाली',
      en: '250+ km Paved Roads & Storm Drains',
    },
  },
  {
    id: 'water',
    num: '03',
    title: {
      gu: 'શુદ્ધ પીવાનું પાણી અને જળ સંચય',
      hi: 'शुद्ध पेयजल और जल संचयन',
      en: 'Water Security',
    },
    summary: {
      gu: 'દરેક ઘરે પૂરતા દબાણથી શુદ્ધ પીવાનું પાણી, ઓવરહેડ ટાંકીઓ અને તળાવોનું ઊંડું ખોદકામ.',
      hi: 'हर घर पर्याप्त दबाव से शुद्ध पेयजल, ओवरहेड टंकियां और तालाबों का गहरीकरण।',
      en: 'Pressurized household tap water, village overhead storage tanks, and check-dam/lake deepening initiatives.',
    },
    target: {
      gu: 'દરેક ફળિયામાં નિયમિત નળ જોડાણ',
      hi: 'हर मोहल्ले में नियमित नल जल',
      en: 'Universal Household Tap Coverage',
    },
  },
  {
    id: 'education',
    num: '04',
    title: {
      gu: 'શિક્ષણ અને સ્માર્ટ શાળાઓ',
      hi: 'शिक्षा और स्मार्ट स्कूल',
      en: 'Education',
    },
    summary: {
      gu: 'સરકારી પ્રાથમિક શાળાઓમાં સ્માર્ટ ક્લાસરૂમ, સોલર પાવર, વિજ્ઞાન પ્રયોગશાળા અને પુસ્તકાલય.',
      hi: 'सरकारी प्राथमिक विद्यालयों में स्मार्ट क्लासरूम, सौर ऊर्जा, विज्ञान प्रयोगशाला और पुस्तकालय।',
      en: 'Smart classrooms, rooftop solar power, science labs, and digital libraries in every government school.',
    },
    target: {
      gu: 'તાલુકાની ૬૦+ શાળાઓનું આધુનિકીકરણ',
      hi: 'तालुका के 60+ स्कूलों का आधुनिकीकरण',
      en: '60+ Modernized Smart Schools',
    },
  },
  {
    id: 'healthcare',
    num: '05',
    title: {
      gu: 'સશક્ત ગ્રામ્ય આરોગ્ય સેવા',
      hi: 'सशक्त ग्रामीण स्वास्थ्य सेवा',
      en: 'Healthcare',
    },
    summary: {
      gu: 'PHC અને CHC કેન્દ્રોમાં સાંજની OPD, વિનામૂલ્યે આવશ્યક દવાઓ, લેબ ટેસ્ટ અને એમ્બ્યુલન્સ નેટવર્ક.',
      hi: 'PHC और CHC केंद्रों में शाम की OPD, मुफ्त आवश्यक दवाएं, लैब जांच और एम्बुलेंस नेटवर्क।',
      en: 'Extended PHC/CHC clinic hours, essential diagnostics, maternal care support, and rapid ambulance response.',
    },
    target: {
      gu: '૨૪x૭ પ્રાથમિક આરોગ્ય સુલભતા',
      hi: '24x7 प्राथमिक स्वास्थ्य सुविधा',
      en: '24x7 Emergency & Diagnostic Access',
    },
  },
  {
    id: 'employment',
    num: '06',
    title: {
      gu: 'યુવા કૌશલ્ય અને રોજગારી',
      hi: 'युवा कौशल और रोजगार',
      en: 'Youth & Employment',
    },
    summary: {
      gu: 'અસોજ અને વાઘોડિયા ઔદ્યોગિક વિસ્તાર સાથે જોડાણ કરી સ્થાનિક યુવાનો માટે રોજગાર મેળા અને તાલીમ.',
      hi: 'असोज और वाघोडिया औद्योगिक क्षेत्र से जोड़कर स्थानीय युवाओं के लिए रोजगार मेले और प्रशिक्षण।',
      en: 'Industry-linked skill centers and direct placement drives connecting Waghodia youth with GIDC employers.',
    },
    target: {
      gu: 'દર વર્ષે ૨,૫૦૦+ યુવાનોને રોજગાર',
      hi: 'प्रति वर्ष 2,500+ युवाओं को रोजगार',
      en: '2,500+ Annual Youth Placements',
    },
  },
  {
    id: 'agriculture',
    num: '07',
    title: {
      gu: 'કૃષિ, સિંચાઈ અને પશુપાલન',
      hi: 'कृषि, सिंचाई और पशुपालन',
      en: 'Agriculture',
    },
    summary: {
      gu: 'કેનાલ માઇનોર મરામત, ખેતર સુધી પાકા રસ્તા, ડ્રિપ ઇરિગેશન સહાય અને ડેરી મંડળી મજબૂતીકરણ.',
      hi: 'नहर मरम्मत, खेतों तक पक्की सड़कें, ड्रिप सिंचाई सहायता और डेयरी समितियों का सुदृढ़ीकरण।',
      en: 'Canal gate maintenance, farm approach lanes, micro-irrigation adoption, and dairy cooperative support.',
    },
    target: {
      gu: '૧૦૦% કેનાલ નેટવર્ક જાળવણી',
      hi: '100% नहर नेटवर्क रखरखाव',
      en: 'Zero-Leakage Minor Canal Network',
    },
  },
  {
    id: 'village_dev',
    num: '08',
    title: {
      gu: 'સમરસ અને સ્વચ્છ ગામ વિકાસ',
      hi: 'समरस और स्वच्छ ग्राम विकास',
      en: 'Village Development',
    },
    summary: {
      gu: 'ડોર-ટુ-ડોર કચરા વ્યવસ્થાપન, ગ્રામ હાટ બજાર, બગીચા અને મહિલા સ્વસહાય જૂથોને પ્રોત્સાહન.',
      hi: 'डोर-टू-डोर कचरा प्रबंधन, ग्राम हाट बाजार, उद्यान और महिला स्वयं सहायता समूहों को प्रोत्साहन।',
      en: 'Door-to-door waste management, village haat markets, community parks, and women SHG micro-enterprise grants.',
    },
    target: {
      gu: 'સ્વચ્છ અને હરિયાળું વાઘોડિયા',
      hi: 'स्वच्छ और हरित वाघोडिया',
      en: 'Clean & Self-Reliant Gram Panchayats',
    },
  },
];
