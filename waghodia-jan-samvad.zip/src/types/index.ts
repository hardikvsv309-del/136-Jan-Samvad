export type Language = 'gu' | 'hi' | 'en';

export type ComplaintStatus = 'submitted' | 'verified' | 'in_progress' | 'resolved';

export type ProblemCategory =
  | 'roads'
  | 'drainage'
  | 'drinking_water'
  | 'electricity'
  | 'education'
  | 'healthcare'
  | 'transport'
  | 'agriculture'
  | 'employment'
  | 'govt_services'
  | 'other';

export interface MediaAttachment {
  url: string;
  type: 'image' | 'video';
  name: string;
}

export interface TimelineEntry {
  id: number;
  status: ComplaintStatus;
  publicNote: string;
  actorName: string;
  createdAt: string;
}

export interface PublicComplaintTrack {
  id: number;
  complaintCode: string;
  village: string;
  category: ProblemCategory;
  title: string;
  description: string;
  status: ComplaintStatus;
  priority: string;
  locationLabel: string;
  actionTaken: string;
  resultSummary: string;
  beforePhotos: string[];
  afterPhotos: string[];
  createdAt: string;
  updatedAt: string;
  resolvedAt: string | null;
}

export interface MapIssuePoint {
  id: number;
  complaintCode: string;
  village: string;
  category: ProblemCategory;
  title: string;
  status: ComplaintStatus;
  latitude: number;
  longitude: number;
  createdAt: string;
}

export interface PublicWorkItem {
  id: number;
  complaintCode: string;
  village: string;
  category: ProblemCategory;
  title: string;
  description: string;
  actionTaken: string;
  resultSummary: string;
  beforePhotos: string[];
  afterPhotos: string[];
  createdAt: string;
  resolvedAt: string | null;
}

export interface PublicUpdateItem {
  id: number;
  titleGu: string;
  titleHi: string;
  titleEn: string;
  summaryGu: string;
  summaryHi: string;
  summaryEn: string;
  category: string;
  village: string;
  publishedAt: string;
}

export interface PublicStats {
  total: number;
  resolved: number;
  underFollowUp: number;
  pending: number;
  resolutionRate: number;
  byCategory: Record<string, number>;
  byVillage: Record<string, { total: number; resolved: number }>;
}

export interface AdminComplaint {
  id: number;
  complaintCode: string;
  citizenName: string;
  mobileNumber: string;
  citizenEmail: string | null;
  village: string;
  category: ProblemCategory;
  title: string;
  description: string;
  latitude: number;
  longitude: number;
  locationLabel: string;
  mediaUrls: MediaAttachment[];
  status: ComplaintStatus;
  priority: string;
  assignedToId: number | null;
  assignedToName: string | null;
  internalNotes: string;
  actionTaken: string;
  resultSummary: string;
  beforePhotos: string[];
  afterPhotos: string[];
  isPublicShowcase: boolean;
  createdAt: string;
  updatedAt: string;
  resolvedAt: string | null;
}

export interface TeamUser {
  id: number;
  uid: string;
  email: string;
  name: string;
  role: string;
  assignedArea: string;
  isActive: boolean;
  createdAt: string;
}

export interface AdminAnalytics {
  monthly: Array<{ period: string; total: number; resolved: number; pending: number }>;
  quarterly: Array<{ period: string; total: number; resolved: number; pending: number }>;
  byCategory: Record<string, number>;
  byVillage: Record<string, { total: number; resolved: number }>;
  avgResolutionDays: number;
  auditLogs: Array<{
    id: number;
    actorEmail: string;
    actorName: string;
    action: string;
    targetCode: string | null;
    details: string;
    createdAt: string;
  }>;
  emailNotifications: Array<{
    id: number;
    complaintCode: string;
    recipientEmail: string;
    subject: string;
    bodyPreview: string;
    deliveryStatus: string;
    createdAt: string;
  }>;
}
